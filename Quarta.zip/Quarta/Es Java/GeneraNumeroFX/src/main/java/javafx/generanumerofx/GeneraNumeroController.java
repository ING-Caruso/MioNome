package javafx.generanumerofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

import java.util.Random;

public class GeneraNumeroController {

    @FXML
    private TextField area;
    @FXML
    private Button button;

    @FXML
    private Label testoFisso;
    @FXML
    private Label testoVariabile;

    @FXML
    private Label tentativi;
    Random rand = new Random();
    private int x = rand.nextInt(20);
    private Integer count = 0;
    @FXML
    void GeneraNumero(ActionEvent event) {
        testoFisso.setText("Immetti un numero");
        testoVariabile.setText("");
        Integer n = Integer.parseInt(area.getText().toString());
        System.out.println(n + " " + x);
        //while(n != x){
        if(n > x){
            testoVariabile.setText("Il Numero ha valore minore");
            count++;
            tentativi.setText("Tentativi : " + count.toString());
        }
        else if(n < x){
            testoVariabile.setText("Il numero ha valore maggiore");
            count++;
            tentativi.setText("Tentativi : " + count.toString());
        }
        else if(n == x) {
            count ++;
            testoVariabile.setText("Hai indovinato con " + count + " tentativi" );
            x = rand.nextInt(20);
            tentativi.setText("Tentativi : " + count.toString());
            count = 0;
        }

    }

}

