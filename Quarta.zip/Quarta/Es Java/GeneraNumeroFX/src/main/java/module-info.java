module javafx.generanumerofx {
    requires javafx.controls;
    requires javafx.fxml;


    opens javafx.generanumerofx to javafx.fxml;
    exports javafx.generanumerofx;
}