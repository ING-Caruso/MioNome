module com.example.suggerimentojavafx {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.graphics;
    requires javafx.base;


    opens com.example.suggerimentojavafx to javafx.fxml;
    exports com.example.suggerimentojavafx;
}