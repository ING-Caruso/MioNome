package com.example.suggerimentojavafx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class SimulatoreController {

    @FXML
    private Button eliminaButton;
    @FXML
    private ListView<String> area;
    @FXML
    private Label labelOK;
    @FXML
    private TextField scelta;
    @FXML
    private Button bottone;
    @FXML
    private Label label1;
    @FXML
    private Label label2;
    private int count;
    private ArrayList<String> parole = new ArrayList<>();
    private ArrayList<String> lista = new ArrayList<>();
    @FXML
    void initialize() throws IOException {
        lista.clear();
        eliminaButton.setVisible(false);
        caricaParole();
        for(int i = 0; i < parole.size(); i++)
            System.out.println(parole.get(i));
    }

    @FXML
    void scegli(ActionEvent event) {
        lista.add(scelta.getText());
        for (int i = 0; i < lista.size(); i++)
            System.out.println(lista.get(i));
            labelOK.setText(labelOK.getText() + " " + lista.get(count));
        count++;
        eliminaButton.setVisible(true);
    }

    @FXML
    void eliminaParola(ActionEvent event) {
        lista.remove(lista.size() - 1);
        labelOK.setText("");
        for (int i = 0; i < lista.size(); i++)
            labelOK.setText(labelOK.getText() + " " + lista.get(i));
        count--;
        if (count < 1)
            eliminaButton.setVisible(false);
    }
    @FXML
    void immettiParola(KeyEvent event) {
        label1.setText(scelta.getText());
        area.getItems().clear();
        try {
            for (int i = 0; i < parole.size(); i++) {
                int s = scelta.getText().length();
                if (parole.get(i).length() >= s && scelta.getText().equals(parole.get(i).substring(0, s))) {
                    area.getItems().add(parole.get(i));
                }
            }
        }catch (Throwable e){}
    }

    @FXML
    void conferma(MouseEvent event) {
        scelta.setText(area.getSelectionModel().getSelectedItem());
        label1.setText(area.getSelectionModel().getSelectedItem());
        lista.add(scelta.getText());

        for (int i = 0; i < lista.size(); i++)
            System.out.println(lista.get(i));
            labelOK.setText(labelOK.getText() + " " + lista.get(count));
        count++;
        eliminaButton.setVisible(true);
    }

    void caricaParole() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("parole.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                parole.add(line);
            }
            reader.close();
        }catch (Throwable e){
            e.printStackTrace();
        }
    }
}