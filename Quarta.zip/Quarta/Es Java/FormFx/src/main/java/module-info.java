module com.example.formfx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.formfx to javafx.fxml;
    exports com.example.formfx;
}