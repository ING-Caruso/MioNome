package com.example.formfx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginOkController{
    @FXML
    private Button logout;
    @FXML
    private TextArea area;

    @FXML
    void esciAccount(ActionEvent event) throws IOException {
        Stage stage = (Stage) logout.getScene().getWindow();
        stage.close();
        Stage stage1 = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(FormApplication.class.getResource("account-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage1.setTitle("Home");
        stage1.setScene(scene);
        stage1.show();
    }
}
