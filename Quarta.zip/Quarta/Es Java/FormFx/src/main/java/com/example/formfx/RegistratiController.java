package com.example.formfx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class RegistratiController implements Serializable{
    @FXML
    private Button button;

    @FXML
    private TextField campoEmail;

    @FXML
    private PasswordField campoPassword;

    @FXML
    private CheckBox ckbutton;

    @FXML
    private Label labelEmail;

    @FXML
    private Label labelPassword;
    @FXML
    private Button buttonIndietro;
    @FXML
    private Label labelTesto;
    @FXML
    private ImageView foto;
    @FXML
    private Label labelErrore;
    private ArrayList<Utente> utenti = new ArrayList<>();
    boolean trova;

    @FXML
    void initialize(){
        caricaUtenti();
        image();
    }
    void image(){
        Image immagine = new Image(getClass().getResourceAsStream("cpa.png"));
        foto.setImage(immagine);
    }
    @FXML
    void aggiungiUtente(String email, String password) throws IOException {
        trova = false;
        Utente utente = new Utente(email,password);
        for (int i = 0; i < utenti.size(); i++) {
            try {
                if (utenti.get(i).getEmail().equals(email)) {
                    labelErrore.setText("L'indirizzo mail risulta già associato ad un account");
                    trova = true;
                }
            } catch (Throwable e) {}
        }
        if(!trova) {
            utenti.add(utente);
            salvaUtenti();
            labelErrore.setText("");
            Stage stage = (Stage) button.getScene().getWindow();
            stage.close();
            Stage stage1 = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(FormApplication.class.getResource("account-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            stage1.setTitle("Home");
            stage1.setScene(scene);
            stage1.show();
        }
    }
    @FXML
    void confermaIscrizione(ActionEvent event) throws IOException {
        if(ckbutton.isSelected())
            aggiungiUtente(campoEmail.getText().toString(), campoPassword.getText().toString());
    }
    public void caricaUtenti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("utenti.bin"));
            utenti = (ArrayList<Utente>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }

    public void salvaUtenti () throws java.io.IOException{
        ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream("utenti.bin"));
        stream.writeObject(utenti);
        stream.close();
    }
    @FXML
    void indietroPage(ActionEvent event) throws IOException {
        Stage stage = (Stage) buttonIndietro.getScene().getWindow();
        stage.close();
        Stage stage1 = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(FormApplication.class.getResource("account-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage1.setTitle("Home");
        stage1.setScene(scene);
        stage1.show();
    }
}

