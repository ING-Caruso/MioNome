package com.example.formfx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class LoginController implements Serializable {

    @FXML
    private Button buttonAccedi;

    @FXML
    private Button buttonIndietro;

    @FXML
    private TextField emailField;

    @FXML
    private Label errore;

    @FXML
    private Label erroreRobot;

    @FXML
    private ImageView foto;

    @FXML
    private PasswordField passwordField;

    @FXML
    private CheckBox robotBox;
    @FXML
    private MenuItem eliminaAccount;

    @FXML
    private MenuItem logout;

    @FXML
    private MenuButton menu;

    @FXML
    private MenuItem visualizzaInformazioni;
    private Utente utente;
    @FXML
    private TextField robotField;
    @FXML
    private ImageView robotImage;

    @FXML
    private Label testoRobot;

    private ArrayList<Utente> utenti = new ArrayList<>();


    @FXML
    void initialize() {
        testoRobot.setVisible(false);
        robotImage.setVisible(false);
        robotField.setVisible(false);
        caricaUtenti();
        image();
    }

    void image() {
        Image immagine = new Image(getClass().getResourceAsStream("cpa.png"));
        foto.setImage(immagine);
    }

    @FXML
    void accediForm(ActionEvent event) throws IOException {
        int k = 0;
        erroreRobot.setText("");
        errore.setText("");
        if (robotBox.isSelected()) {
            boolean giusto = false, errato = false;
            if (robotField.getText().toString().equalsIgnoreCase("captcha")) {
                for (int i = 0; i < utenti.size(); i++) {
                    if (utenti.get(i).getEmail().toString().equals(emailField.getText().toString()) && utenti.get(i).getPassword().toString().equals(passwordField.getText().toString())) {
                        giusto = true;
                        k = i;
                    } else if (utenti.get(i).getEmail().toString().equals(emailField.getText().toString()))
                        errato = true;
                }
                if (giusto) {
                    errore.setText("OKK");
                    Stage stage = (Stage) buttonAccedi.getScene().getWindow();
                    stage.close();
                    Stage stage1 = new Stage();
                    FXMLLoader fxmlLoader = new FXMLLoader(FormApplication.class.getResource("loginOK-view.fxml"));
                    Scene scene = new Scene(fxmlLoader.load());
                    stage1.setTitle("Benvenuto " + utenti.get(k).getEmail());
                    stage1.setScene(scene);
                    stage1.show();
                } else if (errato)
                    errore.setText("*password errata");
                else
                    errore.setText("*utente non trovato");
            } else
                erroreRobot.setText("*testo errato");
        }
    }
    public void caricaUtenti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("utenti.bin"));
            utenti = (ArrayList<Utente>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
    @FXML
    void indietroPage(ActionEvent event) throws IOException {
        Stage stage = (Stage) buttonIndietro.getScene().getWindow();
        stage.close();
        Stage stage1 = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(FormApplication.class.getResource("account-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage1.setTitle("Home");
        stage1.setScene(scene);
        stage1.show();
    }
    @FXML
    void robotClick(ActionEvent event) {
            testoRobot.setVisible(true);
            robotImage.setVisible(true);
            robotField.setVisible(true);
    }
    /*void visualizza(){
        eliminaAccount = new MenuItem("Elimina Account");
        logout = new MenuItem("Esci");
        visualizzaInformazioni = new MenuItem("Visualizza Profilo");
        menu = new MenuButton("Menu" , null,eliminaAccount,logout,visualizzaInformazioni);



    }*/
    void salvaUtente() throws IOException {
        ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream("utente.bin"));
        stream.writeObject(utente);
        stream.close();

    }
}
