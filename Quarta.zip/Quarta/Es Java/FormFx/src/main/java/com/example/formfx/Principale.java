package com.example.formfx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.io.Serializable;
import java.net.URL;
import java.util.ResourceBundle;

public class Principale implements Serializable {

    @FXML
    private Button buttonin;
    @FXML
    private Button buttonoff;
    @FXML
    ImageView foto;
    private Stage stage = new Stage();
    @FXML
    void initialize(URL url, ResourceBundle rb){
        Image immagine = new Image(getClass().getResourceAsStream("cpa.png"));
        foto.setImage(immagine);
    }
    @FXML
    void accediButton(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(FormApplication.class.getResource("login-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Login");
        stage.setScene(scene);
        stage.show();
        Stage stage1 = (Stage) buttonin.getScene().getWindow();
        stage1.close();
    }

    @FXML
    void registrati(ActionEvent event) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(FormApplication.class.getResource("registrati-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Registrati");
        stage.setScene(scene);
        stage.show();
        Stage stage1 = (Stage) buttonoff.getScene().getWindow();
        stage1.close();

        }

}