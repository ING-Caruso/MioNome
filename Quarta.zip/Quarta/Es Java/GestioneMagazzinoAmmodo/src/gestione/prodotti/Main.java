package gestione.prodotti;

import gestione.colori.AnsiFormat;
import gestione.salvataggio.Serializzazione;

import java.util.InputMismatchException;
import java.util.Scanner;

import static gestione.colori.Ansi.colorize;
import static gestione.colori.Attribute.*;

public class Main
{
    public static void main (String[] args) throws java.io.IOException
    {
        Magazzino magazzino = new Magazzino();
        Serializzazione serializzazione = new Serializzazione();
        String marca,modello,seriale,descrizione_prodotto;
        int quantità,età_minima,mesi_garanzia;
        double prezzo;
        magazzino.caricaProdotti();  //carico a inizio programma

        //menu
        Scanner in = new Scanner(System.in);

        //ansi format che definiscono i vari stili
        AnsiFormat menu = new AnsiFormat(BRIGHT_BLUE_TEXT(), BOLD());
        AnsiFormat opzione = new AnsiFormat(BRIGHT_CYAN_TEXT(),BRIGHT_BLACK_BACK(), BOLD());
        AnsiFormat errore = new AnsiFormat(RED_TEXT(),BRIGHT_BLACK_BACK(), BOLD());
        AnsiFormat immettiDati = new AnsiFormat(BRIGHT_CYAN_TEXT());
        AnsiFormat corretto = new AnsiFormat(BRIGHT_GREEN_TEXT(), WHITE_BACK());


        boolean quit = false;

        int scelta = 0;

        do
        {
            System.out.println("\n");
            System.out.println(colorize("#1 aggiungi prodotti", menu));
            System.out.println(colorize("#2 rimuovi prodotti", menu));
            System.out.println(colorize("#3 modifica prodotti", menu));
            System.out.println(colorize("#4 visualizza prodotto", menu));
            System.out.println(colorize("#5 Salva prodotti", menu));
            System.out.println(colorize("#0 esci", menu));
            System.out.println(colorize("Scegli un opzione: ", menu));
            String dato = in.nextLine();
            if(dato.equals("0") || dato.equals("1") || dato.equals("2") || dato.equals("3") || dato.equals("4") || dato.equals("5"))
                scelta = Integer.parseInt(dato);
            else{
                while(!(dato.equals("0") || dato.equals("1") || dato.equals("2") || dato.equals("3") || dato.equals("4") || dato.equals("5"))) {
                    System.out.println(colorize("Hai immesso un opzione errata",menu));
                    System.out.println(colorize("Immetti nuova opzione",menu));
                    dato = in.nextLine();
                }
                scelta = Integer.parseInt(dato);
            }
            String clear ;

            switch (scelta)
            {
                case 1:
                    try
                    {
                        System.out.println(colorize("Hai scelto l'opzione #1", opzione));
                        System.out.println(colorize("Immetti marca", immettiDati));
                        marca = in.nextLine();
                        System.out.println("");

                        System.out.println(colorize("Immetti modello", immettiDati));
                        modello = in.nextLine();
                        System.out.println("");

                        System.out.println(colorize("Immetti seriale", immettiDati));
                        seriale = in.nextLine();
                        System.out.println("");

                        System.out.println(colorize("Immetti quantità", immettiDati));
                        quantità = in.nextInt();

                        while (quantità > 500) {
                            System.out.println(colorize("Non puoi aggiungere più di 500 prodotti", errore));
                            System.out.println(colorize("Immetti quantità", immettiDati));
                            quantità = in.nextInt();
                        }
                        System.out.println("");

                        System.out.println(colorize("Immetti prezzo", immettiDati));

                        prezzo = in.nextDouble();
                        System.out.println("");
                        clear = in.nextLine();
                        System.out.println(colorize("Immetti descrizione prodotto", immettiDati));
                        descrizione_prodotto = in.nextLine();
                        System.out.println("");

                        System.out.println(colorize("Immetti età minima di utilizzo", immettiDati));
                        età_minima = in.nextInt();
                        while (età_minima > 18) {
                            System.out.println(colorize("Non puoi aggiungere un'età minima superiore ai 18 anni", errore));
                            System.out.println(colorize("Immetti età minima", immettiDati));
                            età_minima = in.nextInt();
                        }
                        System.out.println("");

                        System.out.println(colorize("Immetti mesi garanzia", immettiDati));
                        mesi_garanzia = in.nextInt();
                        System.out.println("");

                        System.out.println(colorize("Immetti posizione prodotto", immettiDati));
                        int posizione = in.nextInt();
                        while (posizione >= 100) {
                            System.out.println(colorize("Il magazzino ha 100 posizioni", errore));
                            System.out.println(colorize("Immetti posizione", immettiDati));
                            posizione = in.nextInt();
                        }
                        clear = in.nextLine();
                        magazzino.aggiungiProdotto(marca, modello, seriale, quantità, prezzo, descrizione_prodotto, età_minima, mesi_garanzia, posizione);
                    }catch (InputMismatchException exception) {
                        System.out.println(colorize("Valore espresso in modo errato",errore));
                        System.out.println(colorize("Verrai rimandato al menu principale",menu));
                        clear = in.nextLine();
                        break;
                    }
                        break;

                case 2:
                    try {
                        System.out.println(colorize("Hai scelto l'opzione #2", opzione));
                        System.out.println(colorize("Immetti Seriale", immettiDati));
                        seriale = in.nextLine();
                        System.out.println(colorize("Immetti Quantità", immettiDati));
                        quantità = Integer.parseInt(in.nextLine());
                        magazzino.rimuoviProdotto(seriale, quantità);
                        }catch(InputMismatchException  | NumberFormatException exception){
                            System.out.println(colorize("Valore espresso in modo errato",errore));
                            System.out.println(colorize("Verrai rimandato al menu principale",menu));
                    }
                    break;

                case 3:
                    System.out.println(colorize("Hai scelto l'opzione #3", opzione));
                    System.out.println(colorize("Immetti Seriale", immettiDati));
                    seriale = in.nextLine();
                    magazzino.modificaProdotto(seriale);
                    break;

                case 4:
                    System.out.println(colorize("Hai scelto l'opzione #4", opzione));
                    System.out.println(colorize("Immetti Seriale", immettiDati));
                    String ricerca = in.nextLine();
                    magazzino.visualizzaProdotto(ricerca);

                    break;
                case 5:
                    magazzino.salvaProdotti();
                    System.out.println(colorize("Salvataggio effettuato",corretto));
                    break;

                case 0:
                    quit = true;
                    break;

                default:
                    System.out.println(colorize("scegli un numero valido", errore));
            }

        } while (!quit);
            magazzino.salvaProdotti();
        System.out.println(colorize("arrivederci :)", menu));
    }
}