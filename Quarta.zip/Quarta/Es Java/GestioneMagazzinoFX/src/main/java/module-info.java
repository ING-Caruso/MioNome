module com.example.gestionemagazzinofx {
    requires javafx.controls;
    requires javafx.fxml;
            
                            
    opens com.example.gestionemagazzinofx to javafx.fxml;
    exports com.example.gestionemagazzinofx;
}