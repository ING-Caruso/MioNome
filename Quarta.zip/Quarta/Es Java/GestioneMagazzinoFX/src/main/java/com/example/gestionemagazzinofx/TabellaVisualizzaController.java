package com.example.gestionemagazzinofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class TabellaVisualizzaController {
    private ArrayList <Prodotto> prodotti = new ArrayList<>();
    @FXML
    private TableColumn<Prodotto, String> colonna1;

    @FXML
    private TableColumn<Prodotto, String> colonna2;

    @FXML
    private TableColumn<Prodotto, String> colonna3;

    @FXML
    private TableColumn<Prodotto,Integer> colonna4;

    @FXML
    private TableColumn<Prodotto, Double> colonna5;

    @FXML
    private TableColumn<Prodotto, Boolean> colonna6;

    @FXML
    private TableColumn<Prodotto, String> colonna7;

    @FXML
    private TableColumn<Prodotto, Integer> colonna8 = new TableColumn<>();

    @FXML
    private TableColumn<Prodotto, Integer> colonna9;

    @FXML
    private TableView<Prodotto> tabella = new TableView<>();
    @FXML
    private Button bottoneChiudi;

    @FXML
    void initialize(){
        caricaProdotti();
        for (int i = 0; i < prodotti.size(); i++) {
            System.out.println("passo");
            Prodotto prodotto = new Prodotto(prodotti.get(i).getMarca(), prodotti.get(i).getModello(),
                    prodotti.get(i).getSeriale(), prodotti.get(i).getQuantità()
                    ,prodotti.get(i).getPrezzo(), prodotti.get(i).getDescrizioneProdotto(),
                    prodotti.get(i).getEtaMinima(), prodotti.get(i).getMesiGaranzia());
            tabella.getItems().add(prodotto);
        }
        tabella.getColumns().clear();
        colonna1.setCellValueFactory(new PropertyValueFactory<>("Marca"));
        colonna2.setCellValueFactory(new PropertyValueFactory<>("Modello"));
        colonna3.setCellValueFactory(new PropertyValueFactory<>("Seriale"));
        colonna4.setCellValueFactory(new PropertyValueFactory<>("Quantità"));
        colonna5.setCellValueFactory(new PropertyValueFactory<>("Prezzo"));
        colonna6.setCellValueFactory(new PropertyValueFactory<>("Disponibilità"));
        colonna7.setCellValueFactory(new PropertyValueFactory<>("DescrizioneProdotto"));
        colonna8.setCellValueFactory(new PropertyValueFactory<>("EtaMinima"));
        colonna9.setCellValueFactory(new PropertyValueFactory<>("MesiGaranzia"));
        tabella.getColumns().add(colonna1);
        tabella.getColumns().add(colonna2);
        tabella.getColumns().add(colonna3);
        tabella.getColumns().add(colonna4);
        tabella.getColumns().add(colonna5);
        tabella.getColumns().add(colonna6);
        tabella.getColumns().add(colonna7);
        tabella.getColumns().add(colonna8);
        tabella.getColumns().add(colonna9);
    }
    @FXML
    void tornaPrincipale(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) bottoneChiudi.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("principale-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Home");
        stage.setScene(scene);
        stage.show();

    }
    public void caricaProdotti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("prodotti.bin"));
            prodotti = (ArrayList<Prodotto>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
}