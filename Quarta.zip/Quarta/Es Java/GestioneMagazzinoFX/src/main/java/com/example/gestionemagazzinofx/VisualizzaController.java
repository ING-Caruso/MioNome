package com.example.gestionemagazzinofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class VisualizzaController {
    @FXML
    private Button buttonChiudi;
    @FXML
    private ImageView immagineLogo;
    private ArrayList<Prodotto> prodotti = new ArrayList<>();
    @FXML
    private ListView<String> lista = new ListView<>();

    @FXML
    void tornaPrincipale(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) buttonChiudi.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("principale-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Prodotto");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void initialize(){
        caricaProdotti();
        for(int i = 0; i < prodotti.size(); i++)
            lista.getItems().add(prodotti.get(i).getSeriale());
    }

    @FXML
    void visualizzaInformazioni(MouseEvent event) throws IOException {
        salvaSeriale();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("prodotto-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Prodotto");
        stage.setScene(scene);
        stage.show();
    }
    public void caricaProdotti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("prodotti.bin"));
            prodotti = (ArrayList<Prodotto>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
    public void salvaSeriale () throws java.io.IOException {
        BufferedWriter write = new BufferedWriter(new FileWriter("seriale.txt"));
        String seriale = prodotti.get(lista.getSelectionModel().getSelectedIndex()).getSeriale();
        write.write(seriale + "\n");
        write.close();
    }
}