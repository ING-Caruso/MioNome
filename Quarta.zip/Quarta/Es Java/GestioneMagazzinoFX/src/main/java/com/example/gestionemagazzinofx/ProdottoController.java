package com.example.gestionemagazzinofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class ProdottoController {

    @FXML
    private Button buttonChiudi;

    @FXML
    private Label labelDescrizione;

    @FXML
    private Label labelEtà;

    @FXML
    private Label labelMarca;

    @FXML
    private Label labelModello;

    @FXML
    private Label labelPrezzo;

    @FXML
    private Label labelQuantità;
    @FXML
    private Label labelDisponibilità;
    @FXML
    private Label labelSeriale;
    private ArrayList<Prodotto> prodotti = new ArrayList<>();
    @FXML
    private Label labelGaranzia;
    private String codice ;
    @FXML
    void initialize() throws IOException {
        caricaSeriale();
        caricaProdotti();
        mostra();
    }

    @FXML
    void chiudiFinestra(ActionEvent event) {
        Stage stage1 = (Stage) buttonChiudi.getScene().getWindow();
        stage1.close();
    }
    void mostra() {
        for (int i = 0; i < prodotti.size(); i++)
            if (prodotti.get(i).getSeriale().equals(codice)){
                labelMarca.setText("Marca = " + prodotti.get(i).getMarca());
                labelModello.setText("Modello = " +prodotti.get(i).getModello());
                labelSeriale.setText("Seriale = " + prodotti.get(i).getSeriale());
                labelQuantità.setText("Quantità = " + prodotti.get(i).getQuantità());
                labelPrezzo.setText("Prezzo = " + prodotti.get(i).getPrezzo());
                labelDescrizione.setText("Descrizione prodotto = " + prodotti.get(i).getDescrizioneProdotto());
                labelEtà.setText("Età minima = " + prodotti.get(i).getEtaMinima());
                labelGaranzia.setText("Mesi garanzia = " + prodotti.get(i).getMesiGaranzia());
                labelDisponibilità.setText("Disponibilità = " + prodotti.get(i).disponibile());
            }
    }


    public void caricaSeriale () throws java.io.IOException {
        BufferedReader reader = new BufferedReader(new FileReader("seriale.txt"));
        try {
            codice = reader.readLine();
        } catch(Throwable exception) {
            System.out.println(exception.getMessage());
        }
        reader.close();
    }
    public void caricaProdotti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("prodotti.bin"));
            prodotti = (ArrayList<Prodotto>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
}