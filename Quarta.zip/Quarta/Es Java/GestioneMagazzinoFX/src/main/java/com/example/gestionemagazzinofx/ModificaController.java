package com.example.gestionemagazzinofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class ModificaController {

    @FXML
    private Button confermaButton;
    @FXML
    private ImageView immagineLogo;
    @FXML
    private Label labelErrore;
    @FXML
    private ChoiceBox<String> modificaBox;
    @FXML
    private ChoiceBox<String> boxProdotti;
    private ArrayList<Prodotto> prodotti = new ArrayList<>();
    @FXML
    private TextField textDato;
    @FXML
    private Button bottoneIndietro;

    @FXML
    void initialize(){
        caricaProdotti();
        for (int i = 0; i < prodotti.size(); i++)
            boxProdotti.getItems().add((prodotti.get(i).getSeriale()));
        modificaBox.getItems().addAll("Marca","Modello","Seriale", "Quantità", "Prezzo", "Descrizione prodotto", "Età minima", "Mesi garanzia");
    }
    @FXML
    void confermaModifica(ActionEvent event) throws IOException {
        boolean giusto = false;
        try{
            if (boxProdotti.getSelectionModel().getSelectedItem() != null && modificaBox.getSelectionModel().getSelectedItem() != null && textDato.getText().length() >= 1) {
                for (int i = 0; i < prodotti.size(); i++) {
                    if (modificaBox.getSelectionModel().getSelectedItem().equals("Marca") && boxProdotti.getSelectionModel().getSelectedItem().equals(prodotti.get(i).getSeriale())) {
                        prodotti.get(i).setMarca(textDato.getText());
                        System.out.println(modificaBox.getSelectionModel().getSelectedItem());
                        giusto = true;
                    } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Modello") && boxProdotti.getSelectionModel().getSelectedItem().equals(prodotti.get(i).getSeriale())) {
                        prodotti.get(i).setModello(textDato.getText());
                        giusto = true;
                    } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Seriale") && boxProdotti.getSelectionModel().getSelectedItem().equals(prodotti.get(i).getSeriale())) {
                        prodotti.get(i).setSeriale(textDato.getText());
                        giusto = true;
                    } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Quantità") && boxProdotti.getSelectionModel().getSelectedItem().equals(prodotti.get(i).getSeriale())) {
                        prodotti.get(i).setQuantità(Integer.parseInt(textDato.getText()));
                        giusto = true;
                    } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Prezzo") && boxProdotti.getSelectionModel().getSelectedItem().equals(prodotti.get(i).getSeriale())) {
                        prodotti.get(i).setPrezzo(Double.parseDouble(textDato.getText()));
                        giusto = true;
                    } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Descrizione prodotto") && boxProdotti.getSelectionModel().getSelectedItem().equals(prodotti.get(i).getSeriale())) {
                        prodotti.get(i).setDescrizioneProdotto(textDato.getText());
                        giusto = true;
                    } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Età minima") && boxProdotti.getSelectionModel().getSelectedItem().equals(prodotti.get(i).getSeriale())) {
                        prodotti.get(i).setEtàMinima(Integer.parseInt(textDato.getText()));
                        giusto = true;
                    } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Mesi garanzia") && boxProdotti.getSelectionModel().getSelectedItem().equals(prodotti.get(i).getSeriale())) {
                        prodotti.get(i).setMesiGaranzia(Integer.parseInt(textDato.getText()));
                        giusto = true;
                    }
                    if (giusto) {
                        salvaProdotti();
                        Stage stage1 = (Stage) confermaButton.getScene().getWindow();
                        stage1.close();
                        Stage stage = new Stage();
                        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("principale-view.fxml"));
                        Scene scene = new Scene(fxmlLoader.load());
                        stage.setTitle("Home");
                        stage.setScene(scene);
                        stage.show();
                    } else
                        labelErrore.setText("*errore");
                    giusto = false;
                }
            }
        }catch(Throwable e){
            labelErrore.setText("*errore");
            giusto = false;
        }
    }

    @FXML
    void tornaPrincipale(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) bottoneIndietro.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("principale-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Home");
        stage.setScene(scene);
        stage.show();
    }

    public void caricaProdotti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("prodotti.bin"));
            prodotti = (ArrayList<Prodotto>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
    public void salvaProdotti () throws java.io.IOException{
        ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream("prodotti.bin"));
        stream.writeObject(prodotti);
        stream.close();
        System.out.println("Salvato");
    }
}
