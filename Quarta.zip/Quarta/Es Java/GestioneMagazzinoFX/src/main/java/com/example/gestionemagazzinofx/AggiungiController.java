package com.example.gestionemagazzinofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class AggiungiController {

    @FXML
    private Button confermaButton;
    @FXML
    private ImageView immagineLogo;
    @FXML
    private TextField textDescrizione;
    @FXML
    private Button buttonIndietro;
    @FXML
    private TextField textEtà;
    @FXML
    private TextField textGaranzia;
    @FXML
    private TextField textMarca;
    @FXML
    private TextField textModello;
    @FXML
    private TextField textPrezzo;
    @FXML
    private TextField textQuantità;
    @FXML
    private Label labelErrore;
    @FXML
    private TextField textSeriale;
    private ArrayList<Prodotto> prodotti = new ArrayList<>();

    @FXML
    void confermaAggiunta(ActionEvent event) throws IOException {
        caricaProdotti();
        boolean giusto = false;
        try {
            if (Integer.parseInt(textQuantità.getText()) > 250)
                labelErrore.setText("Non puoi aggiungere più di 250 prodotti");
            else if (Integer.parseInt(textEtà.getText()) > 99 || Integer.parseInt(textEtà.getText()) < 0)
                labelErrore.setText("L'età deve essere compresa tra 0 - 99");
            else {
                Prodotto prodotto = new Prodotto(textMarca.getText(), textModello.getText(), textSeriale.getText(), Integer.parseInt(textQuantità.getText()), Double.parseDouble(textPrezzo.getText()), textDescrizione.getText(), Integer.parseInt(textEtà.getText()), Integer.parseInt(textGaranzia.getText()));
                prodotti.add(prodotto);
                giusto = true;
            }
        }catch (Exception e){
            labelErrore.setText("*Errore");
        }
        if(giusto) {
            salvaProdotti();
            Stage stage1 = (Stage) confermaButton.getScene().getWindow();
            stage1.close();
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("principale-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("Home");
            stage.setScene(scene);
            stage.show();
        }
    }
    @FXML
    void tornaPrincipale(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) buttonIndietro.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("principale-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Home");
        stage.setScene(scene);
        stage.show();

    }
    public void salvaProdotti () throws java.io.IOException{
        ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream("prodotti.bin"));
        stream.writeObject(prodotti);
        stream.close();
        System.out.println("Salvato");
    }
    public void caricaProdotti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("prodotti.bin"));
            prodotti = (ArrayList<Prodotto>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
}