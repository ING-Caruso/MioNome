package com.example.gestionemagazzinofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.MenuButton;
import javafx.scene.control.MenuItem;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class PrincipaleController {

    @FXML
    private MenuItem aggiungiButton;
    @FXML
    private ImageView immagineLogo;
    @FXML
    private MenuItem modificaButton;
    @FXML
    private MenuButton button;
    @FXML
    private MenuItem rimuoviButton;
    @FXML
    private MenuItem visualizzaButton;

    @FXML
    void RimuoviMetodo(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) button.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("rimuovi-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Rimuovi prodotto");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void aggiungiMetodo(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) button.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("aggiungi-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Aggiungi prodotto");
        stage.setScene(scene);
        stage.show();
    }

    @FXML
    void modificaMetodo(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) button.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("modifica-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Modifica prodotto");
        stage.setScene(scene);
        stage.show();

    }

    @FXML
    void visualizzaTabellaMetodo(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) button.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("tabella-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Visualizza tabella prodotti");
        stage.setScene(scene);
        stage.show();

    }
    @FXML
    void visualizzaListaMetodo(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) button.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneMagazzinoApplication.class.getResource("visualizza-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Visualizza lista prodotti");
        stage.setScene(scene);
        stage.show();

    }

}