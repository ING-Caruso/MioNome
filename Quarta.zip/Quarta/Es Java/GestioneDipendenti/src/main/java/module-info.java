module com.example.gestionedipendenti {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.gestionedipendenti to javafx.fxml;
    exports com.example.gestionedipendenti;
}