package com.example.gestionedipendenti;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;

public class VisualizzaController {

    @FXML
    private Button bottoneChiudi;

    @FXML
    private TableColumn<Dipendente, String > colonna1;

    @FXML
    private TableColumn<Dipendente, String > colonna2;

    @FXML
    private TableColumn<Dipendente, Integer> colonna3;

    @FXML
    private TableColumn<Dipendente, String> colonna4;

    @FXML
    private TableView<Dipendente> tabella = new TableView<>();
    private ArrayList<Dipendente> dipendenti = new ArrayList<>();
    @FXML
    void tornaPrincipale(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) bottoneChiudi.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneDipendentiApplication.class.getResource("principale-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();
    }
    @FXML
    void initialize(){
        caricaProdotti();
        for (int i = 0; i < dipendenti.size(); i++) {
            System.out.println(dipendenti.get(i).getCognome());
            Dipendente dipendente = new Dipendente(dipendenti.get(i).getCognome(), dipendenti.get(i).getNome(),
                    dipendenti.get(i).getEtà(), dipendenti.get(i).getCodiceFiscale());
            tabella.getItems().add(dipendente);
        }
        tabella.getColumns().clear();
        colonna1.setCellValueFactory(new PropertyValueFactory<>("Cognome"));
        colonna2.setCellValueFactory(new PropertyValueFactory<>("Nome"));
        colonna3.setCellValueFactory(new PropertyValueFactory<>("Età"));
        colonna4.setCellValueFactory(new PropertyValueFactory<>("CodiceFiscale"));
        tabella.getColumns().add(colonna1);
        tabella.getColumns().add(colonna2);
        tabella.getColumns().add(colonna3);
        tabella.getColumns().add(colonna4);
    }
    public void caricaProdotti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("dipendenti.bin"));
            dipendenti = (ArrayList<Dipendente>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
}
