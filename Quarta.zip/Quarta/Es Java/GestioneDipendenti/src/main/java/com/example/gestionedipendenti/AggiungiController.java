package com.example.gestionedipendenti;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class AggiungiController {

    @FXML
    private Button buttonIndietro;

    @FXML
    private Button confermaButton;
    private ArrayList<Dipendente> dipendenti = new ArrayList<>();
    @FXML
    private ImageView immagineLogo;

    @FXML
    private Label labelErrore;

    @FXML
    private TextField textNome;

    @FXML
    private TextField textCognome;

    @FXML
    private TextField textEtà;

    @FXML
    private TextField textCodiceFiscale;

    @FXML
    void confermaAggiunta(ActionEvent event) throws IOException {
        caricaProdotti();
        boolean giusto = true;
        System.out.println(dipendenti.get(0).getCognome());
            for (int i = 0; i < dipendenti.size(); i++) {
                //System.out.println("pippo");
                System.out.println(dipendenti.get(i).getCognome() + "k" + textCognome.getText());
                if (dipendenti.get(i).getCodiceFiscale().equals(textCodiceFiscale.getText())) {
                    labelErrore.setText("Dipendente già registrato");
                    giusto = false;
                    System.out.println("no");
                } else {
                    giusto = true;
                }
            }
        if(giusto) {
            Dipendente dipendente = new Dipendente(textCognome.getText(), textNome.getText(),Integer.parseInt(textEtà.getText()), textCodiceFiscale.getText());
            dipendenti.add(dipendente);
            salvaProdotti();
            Stage stage1 = (Stage) confermaButton.getScene().getWindow();
            stage1.close();
            Stage stage = new Stage();
            FXMLLoader fxmlLoader = new FXMLLoader(GestioneDipendentiApplication.class.getResource("principale-view.fxml"));
            Scene scene = new Scene(fxmlLoader.load());
            stage.setTitle("Gestione Dipendenti");
            stage.setScene(scene);
            stage.show();
        }
    }
    @FXML
    void tornaPrincipale(ActionEvent event) throws IOException {
        Stage stage1 = (Stage) buttonIndietro.getScene().getWindow();
        stage1.close();
        Stage stage = new Stage();
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneDipendentiApplication.class.getResource("principale-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Home");
        stage.setScene(scene);
        stage.show();
    }
    public void salvaProdotti () throws java.io.IOException{
        ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream("dipendenti.bin"));
        stream.writeObject(dipendenti);
        stream.close();
        System.out.println("salvato");
    }
    public void caricaProdotti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("dipendenti.bin"));
            dipendenti = (ArrayList<Dipendente>) stream.readObject();
            stream.close();
            System.out.println("carica");
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
}

