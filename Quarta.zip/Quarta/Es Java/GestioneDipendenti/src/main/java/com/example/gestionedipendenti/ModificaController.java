package com.example.gestionedipendenti;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.*;
import java.util.ArrayList;

public class ModificaController {

    @FXML
    private ChoiceBox<String> boxDipendenti;
    @FXML
    private Button confermaButton;
    @FXML
    private ImageView immagineLogo;
    @FXML
    private Label labelErrore;
    @FXML
    private ChoiceBox<String> modificaBox;
    @FXML
    private TextField textDato;
    private ArrayList<Dipendente> dipendenti = new ArrayList<>();

    @FXML
    void initialize(){
        caricaProdotti();
        for (int i = 0; i < dipendenti.size(); i++)
            boxDipendenti.getItems().add(dipendenti.get(i).getCognome());
        modificaBox.getItems().addAll("Cognome","Nome","Età", "Codice Fiscale");
    }
    @FXML
    void confermaModifica(ActionEvent event) throws IOException {
        boolean giusto = false;
        if (boxDipendenti.getSelectionModel().getSelectedItem() != null && modificaBox.getSelectionModel().getSelectedItem() != null && textDato.getText().length() >= 1){
            for (int i = 0; i < dipendenti.size(); i++) {
                if (modificaBox.getSelectionModel().getSelectedItem().equals("Nome")) {
                    dipendenti.get(i).setNome(textDato.getText());
                    System.out.println(modificaBox.getSelectionModel());
                    giusto = true;
                } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Cognome")) {
                    dipendenti.get(i).setCognome(textDato.getText());
                    giusto = true;
                } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Età")) {
                    dipendenti.get(i).setEtà(Integer.parseInt(textDato.getText()));
                    giusto = true;
                } else if (modificaBox.getSelectionModel().getSelectedItem().equals("Codice Fiscale")) {
                    dipendenti.get(i).setCodiceFiscale(textDato.getText());
                    giusto = true;
                }
            }
            if (giusto) {
                System.out.println("salva");
                salvaProdotti();
                Stage stage1 = (Stage) confermaButton.getScene().getWindow();
                stage1.close();
                Stage stage = new Stage();
                FXMLLoader fxmlLoader = new FXMLLoader(GestioneDipendentiApplication.class.getResource("principale-view.fxml"));
                Scene scene = new Scene(fxmlLoader.load());
                stage.setTitle("Home");
                stage.setScene(scene);
                stage.show();
            }
        }else{
            labelErrore.setText("*errore");
            System.out.println("pippo");
            System.out.println(modificaBox.getSelectionModel().getSelectedItem());
            System.out.println(  boxDipendenti.getSelectionModel().getSelectedItem());
            System.out.println(textDato.getText().length());
        }
    }
    public void caricaProdotti() {
        try {
            ObjectInputStream stream = new ObjectInputStream(new FileInputStream("dipendenti.bin"));
            dipendenti = (ArrayList<Dipendente>) stream.readObject();
            stream.close();
        }catch (Exception e) {
            System.out.println("Errore " + e.getMessage());
        }
    }
    public void salvaProdotti () throws java.io.IOException{
        ObjectOutputStream stream = new ObjectOutputStream(new FileOutputStream("dipendenti.bin"));
        stream.writeObject(dipendenti);
        stream.close();
        System.out.println("salvato");
    }
}
