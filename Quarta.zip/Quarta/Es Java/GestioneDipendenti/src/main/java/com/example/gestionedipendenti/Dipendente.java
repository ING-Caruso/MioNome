package com.example.gestionedipendenti;

import java.io.Serializable;

public class Dipendente implements Serializable {
    private String nome;
    private String cognome;
    private String codiceFiscale;
    private int età;

    public Dipendente(String cognome, String nome, int età, String codiceFiscale){
        setNome(nome);
        setCognome(cognome);
        setCodiceFiscale(codiceFiscale);
        setEtà(età);
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCognome() {
        return cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getCodiceFiscale() {
        return codiceFiscale;
    }

    public void setCodiceFiscale(String codiceFiscale) {
        this.codiceFiscale = codiceFiscale;
    }

    public int getEtà() {
        return età;
    }

    public void setEtà(int età) {
        this.età = età;
    }
}
