package com.example.gestionedipendenti;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;

public class GestioneDipendentiApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(GestioneDipendentiApplication.class.getResource("principale-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Gestione");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}