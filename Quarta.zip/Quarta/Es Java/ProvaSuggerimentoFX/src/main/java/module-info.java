module com.example.provasuggerimentofx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.provasuggerimentofx to javafx.fxml;
    exports com.example.provasuggerimentofx;
}