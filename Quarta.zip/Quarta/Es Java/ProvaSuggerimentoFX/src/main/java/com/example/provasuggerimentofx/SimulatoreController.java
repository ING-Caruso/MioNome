package com.example.provasuggerimentofx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.paint.Color;


import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class SimulatoreController {

    @FXML
    private ListView<String> area;

    @FXML
    private TextField scelta;

    @FXML
    private Button bottone;

    @FXML
    private Label label1;
    @FXML
    private Label label2;
    private ArrayList<String> parole = new ArrayList<>();
    @FXML
    void initialize() throws IOException {
        caricaParole();
    }

    @FXML
    void scegli(ActionEvent event) {
        try {
            if (area.getSelectionModel().getSelectedItem().equals(null)) {
                label1.setTextFill(Color.color(1, 0, 0));
                label1.setText("Non hai selezionato nessuna opzione");
            }else {
                String parola = area.getSelectionModel().getSelectedItem();
                label1.setText("Hai scelto " + parola);
                label1.setTextFill(Color.web("#000000"));
            }
        }catch(NullPointerException e){
            label1.setTextFill(Color.color(1, 0, 0));
            label1.setText("Non hai selezionato nessuna opzione");
        }
    }

    @FXML
    void immettiParola(KeyEvent event) {
        label1.setText(null);
        area.getItems().clear();
        try {
            for (int i = 0; i < parole.size(); i++) {
                if (parole.get(i).length() >= scelta.getText().length() && scelta.getText().equals(parole.get(i).substring(0, scelta.getText().length()))) {
                    area.getItems().add(parole.get(i));
                }
            }
        }catch (Throwable e){}
    }

    @FXML
    void conferma(MouseEvent event) {
        scelta.setText(area.getSelectionModel().getSelectedItem());
        label1.setText(null);
    }
    void caricaParole() throws IOException {
        BufferedReader reader = new BufferedReader(new FileReader("C:\\Users\\lorec\\Downloads\\CarusoEsercitazioneConVoto\\CarusoEsercitazioneConVoto\\parole.txt"));
        String line;
        while((reader.readLine() ) != null) {
            line = reader.readLine();
            parole.add(line);
        }
        reader.close();
    }
}