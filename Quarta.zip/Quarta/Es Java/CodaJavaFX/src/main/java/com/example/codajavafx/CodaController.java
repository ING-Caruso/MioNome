package com.example.codajavafx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;

public class CodaController {

    @FXML
    private Button bottoneAggiungi;

    @FXML
    private Button bottoneRimuovi;

    @FXML
    private Button bottoneServi;
    @FXML
    private ChoiceBox<String> sceltaRimuovi = new ChoiceBox<>();
    @FXML
    private Label labelTitolo;
    private Integer count = 0;
    private int index;
    @FXML
    private ListView<String> listaPersone = new ListView<>();
    private final ArrayList<String> arrayPersone = new ArrayList<>();
    @FXML
    void aggiungiPersona(ActionEvent event) {
        arrayPersone.add("Persona " + count.toString());
        listaPersone.getItems().add(arrayPersone.get(index));
        sceltaRimuovi.getItems().add("Persona " + count.toString());
        index++;
        count++;
        bottoneServi.setVisible(true);
        bottoneRimuovi.setVisible(true);
        sceltaRimuovi.setVisible(true);
    }
    @FXML
    void initialize(){
        labelTitolo.setText("Simula coda persone");
        index = 0;
        bottoneServi.setVisible(false);
        sceltaRimuovi.setVisible(false);
        bottoneRimuovi.setVisible(false);

    }

    @FXML
    void rimuoviPersona(ActionEvent event) {
        listaPersone.getItems().remove(sceltaRimuovi.getSelectionModel().getSelectedItem());
        arrayPersone.remove(sceltaRimuovi.getSelectionModel().getSelectedItem());
        sceltaRimuovi.getItems().clear();
        sceltaRimuovi.getItems().addAll(arrayPersone);
        index--;

        if(arrayPersone.size() < 1) {
            bottoneServi.setVisible(false);
            sceltaRimuovi.setVisible(false);
            bottoneRimuovi.setVisible(false);
        }
        sceltaRimuovi.getSelectionModel().getSelectedIndex();
    }

    @FXML
    void serviPersona(ActionEvent event) {
        labelTitolo.setText(listaPersone.getItems().get(0) + " è stata servita");
        listaPersone.getItems().remove(arrayPersone.get(0));
        arrayPersone.remove(0);
        sceltaRimuovi.getItems().remove(0);
        sceltaRimuovi.setValue(null);

        if(arrayPersone.size() < 1) {
            bottoneServi.setVisible(false);
            bottoneRimuovi.setVisible(false);
            sceltaRimuovi.setVisible(false);
            count++;
        }
        index--;
    }

}
