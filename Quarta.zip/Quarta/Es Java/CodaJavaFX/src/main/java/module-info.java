module com.example.codajavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.codajavafx to javafx.fxml;
    exports com.example.codajavafx;
}