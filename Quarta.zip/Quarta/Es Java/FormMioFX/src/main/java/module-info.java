module com.example.nulla {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.nulla to javafx.fxml;
    exports com.example.nulla;
}