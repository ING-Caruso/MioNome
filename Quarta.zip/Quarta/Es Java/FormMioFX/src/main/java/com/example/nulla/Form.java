package com.example.nulla;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.io.*;
import java.time.LocalDate;
import java.util.ArrayList;

public class Form {

    @FXML
    private Button button;
    @FXML
    private DatePicker campoData;
    @FXML
    private TextField campoEmail;
    @FXML
    private PasswordField campoPassword;
    @FXML
    private CheckBox ckbutton;
    @FXML
    private Label labelData;
    @FXML
    private Label labelEmail;
    @FXML
    private Label labelPassword;
    @FXML
    private Label labelTesto;
    @FXML
    private Label labelErrore;
    private ArrayList<Utente> utenti = new ArrayList<>();
    boolean trova;

    @FXML
    void initialize() throws IOException {
        caricaUtenti();
        try {
            for (int i = 0; i < utenti.size(); i++)
                System.out.println(utenti.get(i).getEmail() + " aggiunto");
        }catch (Throwable e){}
    }
    @FXML
    void aggiungiUtente(String email, String password,LocalDate data) throws IOException {
        trova = false;
        Utente utente = new Utente(email,password,data);
        for (int i = 0; i < utenti.size(); i++) {
            try {
                if (utenti.get(i).getEmail().equals(email)) {
                    labelErrore.setText("L'indirizzo mail risulta già associato ad un account");
                    trova = true;
                }
            } catch (Throwable e) {}
        }
            if(!trova) {
                utenti.add(utente);
                salvaUtenti();
                labelErrore.setText("");
            }
        }
    @FXML
    void confermaIscrizione(ActionEvent event) throws IOException {
        if(ckbutton.isSelected()) {
            aggiungiUtente(campoEmail.getText().toString(), campoPassword.getText().toString(), campoData.getValue());
        }
    }
    public int getDimensione(){
        return utenti.size();
    }
    public void salvaUtenti () throws java.io.IOException{
        BufferedWriter write =  new  BufferedWriter(new FileWriter("utenti.txt"));
        String email, password, data;
        try {
            for (int i = 0; i < utenti.size(); i++)
                if (utenti.get(i) != null) {
                    email = utenti.get(i).getEmail().toString();
                    password =  utenti.get(i).getPassword().toString();
                    data =  utenti.get(i).getData().toString();
                    System.out.println(email + " " + password + " " + data);
                    write.write(email + " " + password + " " + data + "\n");
               }
        }catch (Exception e){}

        write.close();
        }

    public void caricaUtenti () throws java.io.IOException {
        BufferedReader reader = new BufferedReader(new FileReader("utenti.txt"));
        String email,password,line, elementi[] = new String[3];
        Utente utente;
        try {
            while(true) {
                System.out.println("passo");
                line = reader.readLine();
                elementi = line.split(";");
                //System.out.println(line);
                email = elementi[0];
                password = elementi[1];
                LocalDate data = LocalDate.parse(elementi[2]);
                utente = new Utente(email,password,data);
                utenti.add(utente);
            }
        } catch(Throwable exception) {
            System.out.println(exception.getMessage());
        }
        reader.close();
    }

}
