package com.example.nulla;

import java.io.Serializable;
import java.time.LocalDate;

public class Utente implements Serializable {
    private String email;
    private String password;
    private LocalDate data;

    public Utente(String email, String password, LocalDate data){
        setData(data);
        setEmail(email);
        setPassword(password);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }
}
