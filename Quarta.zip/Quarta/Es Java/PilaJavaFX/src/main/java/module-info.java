module com.example.pilajavafx {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.pilajavafx to javafx.fxml;
    exports com.example.pilajavafx;
}