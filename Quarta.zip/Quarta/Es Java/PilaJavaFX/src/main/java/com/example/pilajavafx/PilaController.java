package com.example.pilajavafx;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;

import java.util.ArrayList;

public class PilaController {

    @FXML
    private Button bottoneAggiungi;

    @FXML
    private Button bottoneRimuovi;
    @FXML
    private Label labelTitolo;
    private Integer count = 0;
    private int index;
    @FXML
    private ListView<String> listaPersone = new ListView<>();
    private  ArrayList<String> arrayPersone = new ArrayList<>();
    private  ArrayList<String> arrayInvertito = new ArrayList<>();

    @FXML
    void aggiungiOggetto(ActionEvent event) {
        arrayPersone.add("Oggetto " + count);
        for(int i = arrayPersone.size(); i <= 0;  i--)
            arrayInvertito.add(arrayPersone.get(i));
        listaPersone.getItems().add(arrayInvertito.get(count));
        count++;
        bottoneRimuovi.setVisible(true);
    }
    @FXML
    void initialize(){
        labelTitolo.setText("Simula pila oggetti");
        bottoneRimuovi.setVisible(false);

    }

    @FXML
    void rimuoviOggetto(ActionEvent event) {
        labelTitolo.setText(listaPersone.getItems().get(listaPersone.getItems().size()-1) + " è stato rimosso");
        listaPersone.getItems().remove(arrayPersone.size()-1);
        arrayPersone.remove(arrayPersone.size()-1);
        count--;
        if(arrayPersone.size() < 1) {
            bottoneRimuovi.setVisible(false);
        }
    }

}
