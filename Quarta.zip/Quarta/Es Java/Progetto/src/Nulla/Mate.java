package Nulla;

import java.util.Scanner;

public class Mate {
	private double x;
	char s;
	private static final double PI_GRECO = Math.PI;
	private static char min = 60;
	private static char ma = 62;
	
	
	public Mate(double x) {
		this.x = x;
	}
	
	public void getSin(double x,char s) {
		double rad,deg,A2,S1,S2;
		rad=Math.asin(x);
		deg = rad*180/PI_GRECO;
		if(deg < 0){
			deg = rad*180/PI_GRECO*(-1)+180;
			A2 = 180-deg+360 ;
		}
		else {
			deg = rad*180/PI_GRECO;	
			A2 = 180 - deg;
		}
		S1 = Math.round(deg);
		S2 = Math.round(A2);
		if(s==min)
			System.out.print(S1 + " +2k Pi < x < "+ S2 +"   +2k Pi \n");
		else if(s==ma)
			System.out.print(S1 + " +2k Pi > x > "+ S2 +"   +2k Pi \n");
		else 
			System.out.println("Errore /n");
	}
	
	public void getCos(double x, char s) {
		double rad,deg,S1,S2,A2;
		rad=Math.acos(x);
		deg = rad*180/PI_GRECO;
		if(deg < 0){
			deg = rad*180/PI_GRECO*(-1)+90;
			A2 = deg ;	
		}
		else {
			deg = rad*180/PI_GRECO;	
			A2 = 360 - deg;
		}
		S1 = Math.round (deg);
		S2 = Math.round (A2);
		if(s==min)
			System.out.println(S1 + " +2k Pi < x < " + S2 + "   +2k Pi");
		else if(s==ma)
			System.out.println(S1 +" +2k Pi > x > " + S2 +"+2k Pi");
		else 
			System.out.println("Errore");
	}
	
	public void getTan(double x, char s) {
		double rad,deg,A2,S1,S2;
		rad=Math.atan(x);
		deg = rad*180/PI_GRECO;
		if(deg < 0){
			deg = rad*180/PI_GRECO+180;
			A2 = deg ;
		}
		else 
			deg = rad*180/PI_GRECO;	
		A2 = 180 + deg;
		S1 = Math.round (deg);
		S2 = Math.round (A2);
		if(s==min)
			System.out.println(S1 + " +2k Pi < x < " + S2 + "   +2k Pi");
		else if(s==ma)
			System.out.println(S1 +" +2k Pi > x > " + S2 +"+2k Pi");
		else 
			System.out.println("Errore");
	}
	public static void main(String args[]) {
		char s = 60;
		double x = -0.5;
		Mate v1 = new Mate (x);
		v1.getSin(x, s);
		
	}
}
