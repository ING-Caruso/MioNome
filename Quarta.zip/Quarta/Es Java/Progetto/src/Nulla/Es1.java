package nulla;

import java.util.Scanner;

public class Es1 {
    public static void main(String[] args) {
        double n,somma = 0;
        int count = 0;
        char e = 232;
        Scanner in = new Scanner(System.in);
        System.out.println("Immetti numero");
        n = in.nextDouble();
        somma = n;
        count++;
        while(n > 0){
            System.out.println("Immetti numero");
            n = in.nextDouble();
            if(n > 0) {
                count++;
                somma += n;
            }
        }
        System.out.println("La somma " + e + " " + somma/count);

    }
}
