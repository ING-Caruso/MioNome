package nulla;

public class Es4 {
    public static void main(String[] args) {
        char e = 232;
        System.out.println("Il risultato " + e + " " + divisione_strana(10));
    }
    static double divisione_strana(double x) {
            if (((x / -3) > 0) && ((x / -3) < 1))
                return x/-3;
            else
                return divisione_strana((x/-3));

    }
}
