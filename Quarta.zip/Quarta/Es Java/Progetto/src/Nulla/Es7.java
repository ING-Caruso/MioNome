package nulla;

import java.util.Scanner;

public class Es7 {
    public static void main(String[] args){
        int n,count = 0,prodotto = 0;
        Scanner in = new Scanner(System.in);
        System.out.println("Immetti numero");
        n = in.nextInt();
        if (n > 0){
            prodotto = n;
            count++;
            while (n > 0){
                System.out.println("Immetti numero");
                n = in.nextInt();
                if(n > 0) {
                    count++;
                    prodotto *= n;
                }
            }
        }
        char e = 232;
        System.out.println("Il prodotto " + e + " " + prodotto);
        System.out.println("Elementi inseriti = " + count);
    }

}
