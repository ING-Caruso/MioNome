package Nulla;

public class Potenza {
	private int base;
	private int esponente;
	
	public Potenza(int base, int esponente) {
		this.base = base;
		this.esponente = esponente;
	}
	public void setBase(int base) {
		this.base = base;
	}
	
	public void setEsponente(int esponente) {
		this.esponente = esponente;
	}
	
	public int pow() {
		int pow = (int) Math.pow(base,esponente);
		System.out.println(pow);
		return pow;
		
	}
	public static void main(String args[]) {
		Potenza numero = new Potenza(2,7);
		numero.pow();
		numero.setBase(3);
		numero.setEsponente(4);
		numero.pow();		
	}
}
