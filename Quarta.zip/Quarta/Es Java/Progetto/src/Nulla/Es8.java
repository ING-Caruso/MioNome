package nulla;

public class Es8 {
    public static void main(String[] args){
        double m = media(5,6);
        System.out.println(m);

    }
    static double media(int a, int b) {

        int max = 0, min = 0, count = 0;
        double somma = 0;
        if (a > b) {
            max = a;
            min = b;
        } else if (a < b) {
            max = b;
            min = a;
        }
        for (int i = min; i <= max; i++) {
            count++;
            somma += i;
        }
        double m = somma / count;

        return m;
    }
}
