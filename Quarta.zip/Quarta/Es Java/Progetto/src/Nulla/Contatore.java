package Nulla;

public class Contatore {
	private int valore;
	
	public Contatore() {
		valore = 0;
	}
	public int setValore(int valore) {
		this.valore++;
		return valore;
	}
	public void stampaInfo() {
		System.out.println(valore);
	}
	public static void main (String args[]) {
		int val = 0;
		Contatore pippo = new Contatore();
		pippo.setValore(val);
		pippo.setValore(val);
		pippo.setValore(val);
		pippo.setValore(val);
		pippo.stampaInfo();
		
	}
}
