package Nulla;

import java.util.Scanner;

public class Punti {
	private int x1;
	private int x2;
	private int y1;
	private int y2;
	private float distanza;
	private float m1;
	private float m2;
	
	Punti(int x1,int y1, int x2, int y2){
		this.x1 = x1;
		this.y1 = y1;
		this.x2 = x2;
		this.y2 = y2;
		this.distanza = (float) Math.sqrt(Math.pow(x2-x1,2)+Math.pow(y2-y1,2));
		this.m1 = (x1+x2)/2f;
		this.m2 = (y1+y2)/2f;
	}
	public void aggiorna() {
		this.distanza = (float) Math.sqrt(Math.pow(x2-x1,2)+Math.pow(y2-y1,2));
		this.m1 = (x1+x2)/2f;
		this.m2 = (y1+y2)/2f;
		
	}
	public float getDistanza() {
		this.distanza =  (float) Math.sqrt(Math.pow(x2-x1,2)+Math.pow(y2-y1,2));
		return distanza;
	}
	public float getPunto_medioX() {
		this.m1=(x1+x2)/2f;
		return m1;
	}
	public float getPunto_medioY() {
		this.m2=(y1+y2)/2f;
		return m2;
	}
	public float setX1(int x1) {
		this.x1 = x1;
		return x1;
	}
	public float setX2(int x2) {
		this.x2 = x2;
		return x2;
	}
	public float setY2(int y2) {
		this.y2 = y2;
		return y2;
	}
	public float setY1(int y1) {
		this.y1 = y1;
		return y1;
	}
	public void stampaInfo() {
		System.out.println("Distanza = "+ distanza);
		System.out.print("Punto Medio = "+ m1);
		System.out.println(" ; " + m2);
	}
	public static void main (String args[]){
		Scanner punto = new Scanner(System.in);
		System.out.print("Immetti X1 ");
		int x1 = punto.nextInt();
		System.out.println();
		System.out.print("Immetti X2 ");
		int x2 = punto.nextInt();
		System.out.println();
		System.out.print("Immetti Y1 ");
		int y1 = punto.nextInt();
		System.out.println();
		System.out.print("Immetti Y2 ");
		int y2 = punto.nextInt();
		System.out.println();
		Punti Pippo = new Punti(x1,x2,y1,y2);
		Pippo.stampaInfo();
		
	}
}