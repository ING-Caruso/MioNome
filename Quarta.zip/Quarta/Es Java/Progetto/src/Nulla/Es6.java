package nulla;

public class Es6 {
    public static void main(String[] args) {
    System.out.println(sommaPari(10));
    }
    static int sommaPari(int n){
        if(n == 1)
            return 2;
        else
            return 2* n + sommaPari(n - 1);

    }
}
