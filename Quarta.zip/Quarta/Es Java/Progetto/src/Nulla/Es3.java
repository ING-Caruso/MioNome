package nulla;

import java.util.Scanner;

public class Es3 {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        char e = 232, u = 250;
        boolean esiste = false;
        long min = 1000000000, n = 1;
        while(n > 0){
            System.out.println("Immetti numero");
            n = in.nextInt();

            if(n > 0) {
                if(n < min )
                    min = n;
                else if (n == min) {
                    esiste = true;

                }
            }
        }
        if (esiste)
            System.out.println("Il minimo " + e + " stato inserito pi" + u + " volte");
        System.out.println("Il minimo " + e + " " + min);
    }
}
