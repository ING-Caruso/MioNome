package nulla;

public class Es5 {
    public static void main(String[] args) {
        verifica_vincitore(1,50);

    }
    static void verifica_vincitore(int a, int b){
        int max = 0,min = 0;
        boolean cerca = false;
        if((a > 0 && a <= 999) && (b > 0 && b <= 999))
            if(a != b) {
                if (a % b == 0)
                    System.out.println("Vincitore a");
                else if (b % a == 0)
                    System.out.println("Vincitore b");
                else {
                    if (a > b) {
                        max = a;
                        min = b;
                        cerca = true;
                    } else if (a < b) {
                        min = a;
                        max = b;
                    }
                    if (((min + 1 % max) == 0 || (min - 1 % max) == 0) && cerca)
                        System.out.println("Vincitore b");
                    else if (((min + 1 % max) == 0 || (min - 1 % max) == 0) && !cerca)
                        System.out.println("Vincitore a");
                    else
                        verifica_vincitore(min, max - 1);
                }
    }
            else
                System.out.println("Pareggio");
        else
            System.out.println("Errore");

    }
}
