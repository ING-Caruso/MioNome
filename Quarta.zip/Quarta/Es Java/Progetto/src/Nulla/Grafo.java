package Nulla;

import java.io.*;
import java.util.*;

public class Grafo {
	int[] vertex;
	int[][] edges;

	public Grafo(String filePath, String splitBy) {
		Set<Integer> nodi=leggiGrafo(filePath,splitBy);
		this.vertex= new int [nodi.size()];
		int i=0;
		for (int nodo : nodi) {
			vertex[i]=nodo;
			i++;
		}
		this.edges = leggiGrafo(filePath, splitBy, nodi);
	}

	public static void main(String[] args) {
		Grafo g =  new Grafo("C:\\Users\\lorec\\Downloads\\grafo.txt" , ",");
		System.out.println(g.toString());
	}

	public static Set<Integer> leggiGrafo(String filePath, String splitBy) {
		Set<Integer> nodes = new HashSet<Integer>();
		String line = "";
		try {
			// parsing a CSV file into BufferedReader class constructor
			BufferedReader br = new BufferedReader(new FileReader(filePath));
			while ((line = br.readLine()) != null) {
				String[] edgeToParse = line.split(splitBy);
				System.out.println(	"Sorgente=" 		+ edgeToParse[0] +
									" Destinazione=" 	+ edgeToParse[1] +
									" Peso= "		 	+ edgeToParse[0]);
				for (String n : edgeToParse)
					nodes.add(Integer.parseInt(n));
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return nodes;
	}

	public static int[][] leggiGrafo(String filePath, String splitBy, Set<Integer> nodi) {
		int[][] archi = new int[nodi.size()-1][nodi.size()-1];
		String line = "";
		try {
			// parsing a CSV file into BufferedReader class constructor
			BufferedReader br = new BufferedReader(new FileReader(filePath));
			while ((line = br.readLine()) != null) {
				String[] edgeToParse = line.split(splitBy);
				archi	[Integer.parseInt(edgeToParse[0])]
						[Integer.parseInt(edgeToParse[1])] = Integer.parseInt(edgeToParse[2]);
			}
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return archi;
	}

	@Override
	public String toString() {
		String s = "VERTICI: " + Arrays.toString(this.vertex) + "\nARCHI: \n";
		for (int[] a : this.edges)
			s += Arrays.toString(a) + "\n";
		return s;

	}
}