package nulla;

import java.util.Scanner;

public class Es2 {
    public static void main(String[] args) {
        char e = 232;
        Scanner in = new Scanner(System.in);
        System.out.println("Immetti primo numero ");
        int a = in.nextInt();
        int b = in.nextInt();
        System.out.println("Il prodotto " + e + " " + calcola(a,b));
    }
    static int calcola(int a, int b){
        int max = 0, min = 0, prodotto = 1;
        if(a >= b)
            return 0;
        else {
            max = b;
            min = a;
        }
        for(int i = min + 1; i < max; i++)
            prodotto *= i;
        return prodotto;
    }
}
