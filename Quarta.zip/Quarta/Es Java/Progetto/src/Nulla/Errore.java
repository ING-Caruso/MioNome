package Nulla;

public class Errore{

}