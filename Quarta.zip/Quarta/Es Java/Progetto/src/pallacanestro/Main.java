package pallacanestro;

import java.util.Scanner;

public class Main{
	public static void main(String args[]){
		Scanner input = new Scanner (System.in);  
		Palla p1 = new Palla(0, 0, 0, 0);
		Canestro c1 = new Canestro(0, 0, 0);
		
		double n;
		int scelta = 1;
		
	System.out.println("Inserisci la posizione x della palla: ");
	n = input.nextDouble();
	p1.setX0(n);

	System.out.println("\nInserisci la posizione y della palla: ");
	n = input.nextDouble();
	p1.setY0(n);

	System.out.println("\nInserisci la potenza della palla (m/s): ");
	n = input.nextDouble();
	p1.setV0(n);

	System.out.println("\nInserisci l'angolo di tiro della palla: ");
	n = input.nextDouble();
	p1.setA0(n);


	System.out.println("\nInserisci la posizione x del cantro del canestro: ");
	n = input.nextDouble();
	c1.setX(n);

	System.out.println("\nInserisic la posizione y del centro del canestro: ");
	n = input.nextDouble();
	c1.setY(n);

	System.out.println("\nInserisci il raggio del canestro: ");
	n = input.nextDouble();
	c1.setR(n);

	while(scelta == 1 || scelta == 2 || scelta == 3){
		
		System.out.println("1) Calcola tiro;\n");
		System.out.println("2) Visualizza valori;\n");
		System.out.println("3) Modifica valori;\n");
		System.out.println("4) Esci;\n\n");
		
		System.out.println(">> ");
		scelta = input.nextInt();
		
		switch(scelta){
			case 1:
				System.out.println("\n");
				
				p1.calcola(c1);
				
				System.out.println("\n\n");
				new java.util.Scanner(System.in).nextLine();
				
				break;
			
			case 2:
				System.out.println("");
				System.out.println("PALLA: \n");
				System.out.println("Posizione: (" + p1.getX0() + ", " + p1.getY0() + ");\n");
				System.out.println("Potenza: " + p1.getV0() + " m/s;\n");
				System.out.println("Angolo: " + p1.getA0() + " gradi;\n\n");
				
				System.out.println("CANESTRO: \n");
				System.out.println("Posizione: (" + c1.getX() + ", " + c1.getY() + ");\n");
				System.out.println("Raggio: " + c1.getR() + " m.\n\n");
				
				new java.util.Scanner(System.in).nextLine();
				
				break;
			
			case 3:
				scelta = 1;
				
				while(scelta == 1 || scelta == 2){
					//system("cls");
					
					System.out.println("MODIFICA\n\n");
					System.out.println("1) Palla;\n");
					System.out.println("2) Canestro;\n");
					System.out.println("3) Torna indietro;\n\n");
					
					System.out.println(">> ");
					scelta = input.nextInt();
					
					switch(scelta){
						case 1:
							while(scelta >= 1 && scelta <= 5){
								//system("cls");
								
								System.out.println("MODIFICA PALLA\n");
								System.out.println("1) Posizione x;");
								System.out.println("2) Posizione y;");
								System.out.println("3) Potenza;");
								System.out.println("4) Angolo;");
								System.out.println("5) Tutto;");
								System.out.println("6) Torna indietro;\n\n");
								
								System.out.println(">> ");
								scelta = input.nextInt();
								
								System.out.println("");
								
								switch(scelta){
									case 1:
										System.out.println("Inserisci la posizione x della palla: ");
										n = input.nextDouble();
										p1.setX0(n);
										
										break;
									
									case 2:
										System.out.println("Inserisci la posizione y della palla: ");
										n = input.nextDouble();
										p1.setY0(n);
										
										break;
									
									case 3:
										System.out.println("Inserisci la potenza della palla (m/s): ");
										n = input.nextDouble();
										p1.setV0(n);
										
										break;
									
									case 4:
										System.out.println("Inserisci l'angolo di tiro della palla: ");
										n = input.nextDouble();
										p1.setA0(n);
										
										break;
									
									case 5:
										System.out.println("Inserisci la posizione x della palla: ");
										n = input.nextDouble();
										p1.setX0(n);
										
										System.out.println("Inserisci la posizione y della palla: ");
										n = input.nextDouble();
										p1.setY0(n);
										
										System.out.println("Inserisci la potenza della palla (m/s): ");
										n = input.nextDouble();
										p1.setV0(n);
										
										System.out.println("Inserisci l'angolo di tiro della palla: ");
										n = input.nextDouble();
										p1.setA0(n);
										
										break;
									
									default:
										break;
								}
							}
							
							scelta = 1;
							
							break;
						
						case 2:
							while(scelta >= 1 && scelta <= 4){
								//system("cls");
								
								System.out.println("MODIFICA CANESTRO\n\n");
								System.out.println("1) Posizione x;");
								System.out.println("2) Posizione y;");
								System.out.println("3) Raggio;");
								System.out.println("4) Tutto;");
								System.out.println("5) Torna indietro;\n\n");
								
								System.out.println(">> ");
								scelta = input.nextInt();
								
								System.out.println("");
								
								switch(scelta){
									case 1:
										System.out.println("Inserisci la posizione x del canestro: ");
										n = input.nextDouble();
										c1.setX(n);
										
										break;
									
									case 2:
										System.out.println("Inserisci la posizione y del canestro: ");
										n = input.nextDouble();
										c1.setY(n);
										
										break;
									
									case 3:
										System.out.println("Inserisci il raggio del canestro: ");
										n = input.nextDouble();
										c1.setR(n);
										
										break;
									
									case 4:
										System.out.println("\nInserisci la posizione x del cantro del canestro: ");
										n = input.nextDouble();
										c1.setX(n);
										
										System.out.println("\nInserisic la posizione y del centro del canestro: ");
										n = input.nextDouble();
										c1.setY(n);
										
										System.out.println("\nInserisci il raggio del canestro: ");
										n = input.nextDouble();
											c1.setR(n);
										
										default:
											break;
									}
								}
								
								scelta = 1;
								
								break;
							
							default:
								break;
						}
					}
					
					scelta = 1;
					
					break;
				
				default:
					break;
			}
		}
	}


}
