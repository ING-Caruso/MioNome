package pallacanestro;

class Canestro{
	private double x;	// posizione x del centro
	private double y;	// posizione y del centro
	private double r;	// raggio
		
		public Canestro(double x, double y, double r){
			setX(x);
			setY(y);
			setR(r);
		}
		
		public Canestro(){
			x = 0;
			y = 0;
			r = 0;
		}
		
		public double getX(){
			return x;
		}
		public void setX(double x){
			this.x = x;
		}
		
		double getY(){
			return y;
		}
		
		void setY(double y){
			this.y = y;
		}
		
		double getR(){
			return r;
		}
		
		void setR(double r){
			if(r > 0){
				this.r = r;
			}
		}
}

	class Palla{
		private double x0;
		private double y0;
		private double v0;
		private double a0;
	
		public Palla(double x, double y, double v, double a){
			x0 = x;
			y0 = y;
			v0 = v;
			a0 = a;
		}
		
		public Palla(){
			x0 = 0;
			y0 = 0;
			v0 = 0;
			a0 = 0;
		}
		
		public double getX0(){
			return x0;
		}
		public void setX0(double x0){
			this.x0 = x0;
		}
		
		public double getY0(){
			return y0;
		}
		public void setY0(double y0) {
			this.y0 = y0;
		}
		
		double getV0(){
			return v0;
		}
		
		void setV0(double v0){
			this.v0 = v0;
		}
		
		public double getA0(){
			return a0;
		}
		public void setA0(double a0){
			this.a0 = a0;
		}
		
		public boolean calcola(Canestro c1){
			if(x0 <= c1.getX() - c1.getR()){		// se la palla si trova a sinistra rispetto al canestro
			double vx0 = v0 * Math.cos(a0 * Math.PI / 180);	// calcolo della componente x della velocità
			double vy0 = v0 * Math.sin(a0 * Math.PI / 180);	// calcolo della componente y della velocità
			
			double t1 = (c1.getX() - c1.getR() - x0) / vx0;		// tempo impiegato dalla palla per raggiunge la x dell'inizio del canestro(x - raggio)
			double t2 = (c1.getX() + c1.getR() - x0) / vx0;		// tempo impiegato dalla palla per superare la x della fine del canestro(x + raggio)
			
			double y1 = -0.5 * 9.81 * Math.pow(t1, 2) + vy0 * t1 + y0;	// altezza della palla quando raggiunge la x dell'inizio del canestro (al tempo t1)
			double y2 = -0.5 * 9.81 * Math.pow(t2, 2) + vy0 * t2 + y0;	// altezza della palla quando raggiunge la x della fine del canestro (al tempo t2)
			
			if(y1 > c1.getY() && y2 < c1.getY()){
				System.out.println( "CANESTRO ESEGUITO");
				
				double t = (vy0 + Math.sqrt(Math.pow(vy0, 2) - 4 * c1.getY() + 4 * y0)) / 9.81;	// calcolo del tempo impiegato alla palla per entrare
			
				if(t < t1){	// la prima soluzione potrebbe non essere quella corretta
					t = (vy0 - Math.sqrt(Math.pow(vy0, 2) - 4 * c1.getY() + 4 * y0)) / 9.81;		// seconda soluzione
				}
				
				System.out.println( "Tempo impiegato: " + t + " s" );
				
				double xt = t * vx0 + x0;	// posizione x della palla quando entra nel canestro
				double p;
				
				if(xt > c1.getX()){
					p  = (c1.getX() + c1.getR() - xt) / c1.getR() * 100;
				}
				else{
					p  = (xt - (c1.getX() - c1.getR())) / c1.getR() * 100;
				}
				
				System.out.println("Precisione: " + p + "%");
				
				return true;
			}
		}
		else if(x0 >= c1.getX() + c1.getR()){	// se la palla si trova a destra del canestro

			double vx0 = v0 * Math.cos(a0 * 3.1415926535 / 180);	// calcolo della componente x della velocità
			double vy0 = v0 * Math.sin(a0 * 3.1415926535 / 180);	// calcolo della componente y della velocità
			
			double t1 = (c1.getX() - c1.getR() - x0) / vx0;		// tempo impiegato dalla palla per raggiunge la x dell'inizio del canestro(x - raggio)
			double t2 = (c1.getX() + c1.getR() - x0) / vx0;		// tempo impiegato dalla palla per superare la x della fine del canestro(x + raggio)
			
			double y1 = -0.5 * 9.81 * Math.pow(t1, 2) + vy0 * t1 + y0;	// altezza della palla quando raggiunge la x dell'inizio del canestro (al tempo t1)
			double y2 = -0.5 * 9.81 * Math.pow(t2, 2) + vy0 * t2 + y0;	// altezza della palla quando raggiunge la x della fine del canestro (al tempo t2)
			
			if(y1 < c1.getY() && y2 > c1.getY()){
				System.out.println("CANESTRO ESEGUITO");
				
				double t = (vy0 + Math.sqrt(Math.pow(vy0, 2) - 4 * c1.getY() + 4 * y0)) / 9.81;	// calcolo del tempo impiegato alla palla per entrare
			
				if(t < t2){	// la prima soluzione potrebbe non essere quella corretta
					t = (vy0 - Math.sqrt(Math.pow(vy0, 2) - 4 * c1.getY() + 4 * y0)) / 9.81;		// seconda soluzione
				}
				
				System.out.println("Tempo impiegato: " + t + " s");
				
				double xt = t * vx0 + x0;	// posizione x della palla quando entra nel canestro
				double p;
				
				if(xt > c1.getX()){
					p  = (c1.getX() + c1.getR() - xt) / c1.getR() * 100;
				}
				else{
					p  = (xt - (c1.getX() - c1.getR())) / c1.getR() * 100;
				}
				
				System.out.println("Precisione: " + p + "%");
				
				return true;
			}
		}
		else if(y0 >= c1.getY()){	// se la palla si trova sopra il canestro
		
			if(v0 == 0){
				System.out.println("CANESTRO ESEGUITO");
				
				double vy0 = v0 * Math.sin(a0 * Math.PI / 180);	// calcolo della componente y della velocità
				
				double t = (vy0 + Math.sqrt(Math.pow(vy0, 2) - 4 * c1.getY() + 4 * y0)) / 9.81;	// calcolo del tempo impiegato alla palla per entrare
					
				System.out.println("Tempo impiegato: " + t + " s");
				
				double p;
					
				if(x0 > c1.getX()){
					p  = (c1.getX() + c1.getR() - x0) / c1.getR() * 100;
				}
				else{
					p  = (x0 - (c1.getX() - c1.getR())) / c1.getR() * 100;
				}
				
				System.out.println("Precisione: " + p + "%");
				
				return true;
			}
			else if(a0 == 90 || a0 == 270){
				System.out.println("CANESTRO ESEGUITO");
				
				double vy0 = v0 * Math.sin(a0 * 3.1415926535 / 180);	// calcolo della componente y della velocità
				
				double t = (vy0 + Math.sqrt(Math.pow(vy0, 2) - 4 * c1.getY() + 4 * y0)) / 9.81;	// calcolo del tempo impiegato alla palla per entrare
					
				System.out.println("Tempo impiegato: " + t + " s");
				
				double p;
					
				if(x0 > c1.getX()){
					p  = (c1.getX() + c1.getR() - x0) / c1.getR() * 100;
				}
				else{
					p  = (x0 - (c1.getX() - c1.getR())) / c1.getR() * 100;
				}
				
				System.out.println("Precisione: " + p + "%");
					
				return true;
			}
			else if(Math.cos(a0 * Math.PI / 180) > 0){
				double vx0 = v0 * Math.cos(a0 * Math.PI / 180);	// calcolo della componente x della velocità
				double vy0 = v0 * Math.sin(a0 * Math.PI / 180);	// calcolo della componente y della velocità
				
				double t2 = (c1.getX() + c1.getR() - x0) / vx0;		// tempo impiegato dalla palla per superare la x della fine del canestro(x + raggio)
				
				double y2 = -0.5 * 9.81 * Math.pow(t2, 2) + vy0 * t2 + y0;	// altezza della palla quando raggiunge la x della fine del canestro (al tempo t2)
				
				if(y2 < c1.getY()){
					System.out.println("CANESTRO ESEGUITO");
					
					double t = (vy0 + Math.sqrt(Math.pow(vy0, 2) - 4 * c1.getY() + 4 * y0)) / 9.81;	// calcolo del tempo impiegato alla palla per entrare
					
					System.out.println("Tempo impiegato: " + t + " s");
					
					double xt = t * vx0 + x0;	// posizione x della palla quando entra nel canestro
					double p;
					
					if(xt > c1.getX()){
						p  = (c1.getX() + c1.getR() - xt) / c1.getR() * 100;
					}
					else{
						p  = (xt - (c1.getX() - c1.getR())) / c1.getR() * 100;
					}
					
					System.out.println("Precisione: " + p + "%");
					
					return true;
				}
			}
			else{
				double vx0 = v0 * Math.cos(a0 * Math.PI / 180);	// calcolo della componente x della velocità
				double vy0 = v0 * Math.sin(a0 * Math.PI / 180);	// calcolo della componente y della velocità
				
				double t1 = (c1.getX() - c1.getR() - x0) / vx0;		// tempo impiegato dalla palla per raggiunge la x dell'inizio del canestro(x - raggio)
				
				double y1 = -0.5 * 9.81 * Math.pow(t1, 2) + vy0 * t1 + y0;	// altezza della palla quando raggiunge la x dell'inizio del canestro (al tempo t1)
				
				if(y1 < c1.getY()){
					System.out.println("CANESTRO ESEGUITO");
					
					double t = (vy0 + Math.sqrt(Math.pow(vy0, 2) - 4 * c1.getY() + 4 * y0)) / 9.81;	// calcolo del tempo impiegato alla palla per entrare
					
					System.out.println("Tempo impiegato: " + t + " s");
					
					double xt = t * vx0 + x0;	// posizione x della palla quando entra nel canestro
					double p;
					
					if(xt > c1.getX()){
						p  = (c1.getX() + c1.getR() - xt) / c1.getR() * 100;
					}
					else{
						p  = (xt - (c1.getX() - c1.getR())) / c1.getR() * 100;
					}
					
					System.out.println("Precisione: " + p + "%");
					
					return true;
				}
			}
		}
		
			System.out.println("CANESTRO FALLITO");
			
			return false;
	}
}