package datatime;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.time.Period;

public class Main {

	public static void main(String[] args) {
		LocalDate data = LocalDate.of(2022, Month.DECEMBER, 2);
		System.out.println(data);
		LocalDate data1 = data.minusMonths(3);
		System.out.println(data1);
		LocalDate data2 = data.plusDays(10);
		System.out.println(data2);
		LocalDate data3 = LocalDate.of(2022, Month.DECEMBER, 23);
		Period periodo = Period.between(data, data3);
		System.out.println(periodo);
		
		LocalTime tempo = LocalTime.of(21,23);
		System.out.println(tempo);
		LocalTime tempo1 = tempo.minusMinutes(3);
		System.out.println(tempo1);
		LocalTime tempo2 = tempo.plusHours(1);
		System.out.println(tempo2);
		
		LocalDateTime dt = LocalDateTime.of(data, tempo);
		LocalDateTime dt1 = dt.minusMonths(10);
		System.out.println(dt1);
		LocalDateTime dt2 = dt.plusYears(3);
		System.out.println(dt2);
		boolean bisestile = data.isLeapYear();
		if (bisestile == true)
			System.out.println("Bisestile");
		else
			System.out.println("Non Bisestile");
		LocalDate data4 = LocalDate.of(2023,Month.MARCH,23);
		Period periodo1 = Period.between(data, data4);
		System.out.println(periodo1);
	}

}
