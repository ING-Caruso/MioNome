package figurageometrica.rettangolo;

public class Punto {
	private double x;
	private double y;
	
	public Punto(double x, double y) {
		this.x = x;
		this.y = y;
	}
	public Punto(Punto p) {
		x = p.getX();
		y = p.getY();
	}
	public void setX(double x) {
		this.x = x;
	}
	
	public void setY(double y) {
		this.y = y;
	}
	
	public double getX() {
		return x;
	}
	
	public double getY() {
		return y;
	}
	
	public double getDistanza(Punto p) {
		double dx = x-p.getX();
		double dy = y-p.getY();
		return Math.sqrt(Math.pow(dx,2)+Math.pow(dy,2));
	}
	public boolean equals(Punto z) {
		return ((x == z.getX()) && (y == z.getY()));	
	}
}
