package figurageometrica.rettangolo;

public class FiguraGeometrica {
	
	public FiguraGeometrica() {
	}
	
	public double calcolaArea() {
		return 0;
	}
}
