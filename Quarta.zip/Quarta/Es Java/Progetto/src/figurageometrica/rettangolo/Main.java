package figurageometrica.rettangolo;

public class Main {
	public static void main(String[] args) {
		char E = 200;
		char e = 232;
		
		Punto p1 = new Punto(2,2);
		Punto p2 = new Punto(7,2);
		Punto p3 = new Punto(7,5);
		Punto p4 = new Punto(2,5);
		Rettangolo r1 = new Rettangolo (p1, p2, p3, p4);
		System.out.println("Area = " + r1.calcolaArea(p1, p2, p3, p4));
		
		if(r1.controllaRettangolo(p1, p2, p3, p4) == true)
			System.out.println(E + " un rettangolo");
		else
			System.out.println("Non " + e + " un rettangolo");
		}
}
