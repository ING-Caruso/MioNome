package figurageometrica.rettangolo;

public class Rettangolo {
	private Punto a;
	private Punto b;
	private Punto c;
	private Punto d;
	
	public Rettangolo(Punto a, Punto b, Punto c, Punto d) {
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}
	public Rettangolo(Rettangolo t) {
		this.a = t.getA();
		this.b = t.getB();
		this.c = t.getC();
		this.d = t.getC();
	}
	
	public void setA(Punto a) {
		this.a = new Punto(a);	
	}
	
	public void setB(Punto b) {
		this.b = new Punto(b);
	}
	
	public void setC(Punto c) {
		this.c = new Punto(c);
	}
	
	public void setD(Punto d) {
		this.d = new Punto(d);
	}
	
	public Punto getA() {
		return a;
	}
	
	public Punto getB() {
		return b;
	}
	
	public Punto getC() {
		return c;
	}
	
	public Punto getD() {
		return d;
	}
	
	public double getLato(Punto p1,Punto p2) {
		return Math.sqrt((Math.pow(p2.getX() - p1.getX(), 2) + Math.pow(p2.getY() - p1.getY(), 2)));
	}
	
	
	public double calcolaArea(Punto p1, Punto p2, Punto p3, Punto p4) {
		return getLato(p1,p2)*getLato(p1,p4);
	}
	
	public boolean controllaRettangolo(Punto p1, Punto p2 , Punto p3 , Punto p4) {
		if(getLato(p1,p2) == getLato(p3,p4) && getLato(p2,p3) == getLato(p1,p4) && getLato(p1,p2) != getLato(p2,p3) && p1.getX() == p4.getX() && p2.getX() == p3.getX() && p1.getY() == p2.getY() && p3.getY() == p4.getY()) 
			return true;
		else
			return false;
	}
}