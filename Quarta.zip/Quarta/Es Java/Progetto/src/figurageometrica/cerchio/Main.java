package figurageometrica.cerchio;

public class Main {

	public static void main(String[] args) {
		char due = 178;
		Cerchio c1 = new Cerchio (3);
		Cerchio c2 = new Cerchio (5);
		Cerchio c3 = new Cerchio (10,70);
		
		System.out.println("Area 1 = " + c1.calcolaArea()+" cm" + due);
		System.out.println("Area 2 = " + c2.calcolaArea()+" cm" + due);
		System.out.println("Circonferenza 1 = " + c1.calcolaCirconferenza() + " cm");
		System.out.println("Circonferenza 2 = " + c2.calcolaCirconferenza() + " cm");
		System.out.println("Raggio Cerchio 3 = " + c3.calcolaRaggio() + " cm");
		
		
	
		

	}

}
