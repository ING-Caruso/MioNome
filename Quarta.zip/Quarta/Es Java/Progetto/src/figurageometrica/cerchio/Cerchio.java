package figurageometrica.cerchio;

public class Cerchio extends Figura {
	private static final double PI_GRECO = Math.PI;
	private final double raggio;
	private double area;
	private double circonferenza;
	
	public Cerchio(double raggio){
		this.raggio = raggio;	
	}
	
	public Cerchio(double pippo, double area) {
		this.area = area;
		raggio = calcolaRaggio();
		circonferenza = calcolaCirconferenza();
	}

	public double getRaggio() {
		return raggio;
	}
	
	public double calcolaCirconferenza() {
		circonferenza = 2*raggio*PI_GRECO;
		return circonferenza;
	}
	
	public double calcolaArea() {
		area = Math.pow(raggio, 2)*PI_GRECO;
		return area;
	}
	
	public double calcolaRaggio() {
		return Math.sqrt(area/PI_GRECO);
	}
	
	public boolean controlloDati() {
		if (raggio > 0 && area >0)
			return true;
		else
			return false;
	}
}