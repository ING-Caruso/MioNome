package figurageometrica.cerchio;

public class Figura {
	
	public Figura() {
	}
}