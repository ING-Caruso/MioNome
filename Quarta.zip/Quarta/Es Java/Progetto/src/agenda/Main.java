package agenda;

import java.io.IOException;
import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.Month;

public class Main {

	public static void main(String[] args) throws IOException {
		Agenda agenda = new Agenda();
		try {
			LocalDate data = LocalDate.of(2022, Month.NOVEMBER, 12);
			Appuntamento a1 = new Appuntamento(data,"Casa","nulla");
			Appuntamento a2 = new Appuntamento(data,"Ciao","Rosso");
			agenda.aggiungiAppuntamento(a1, 0);
			agenda.stampaInfo();
			agenda.rimuoviAppuntamento(a1);
			agenda.stampaInfo();
			agenda.aggiungiAppuntamento(a1, 0);
			agenda.modificaAppuntamento(a1,a2);
			agenda.caricaAgenda("ss.txt");
			agenda.salvaAgenda();
			agenda.stampaInfo();
		}
		catch(DateTimeException exception) {
			System.out.println("Data non valida");
		}
	}
}
