package agenda;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


public class File {
	private char tipo;
	private BufferedReader reader;
	private BufferedWriter writer;

	
	public File(String percorso, char tipo) throws IOException{
		setTipo('R');
		if( tipo=='w' || tipo=='W'){ 
			setTipo('w');
			writer = new BufferedWriter(new FileWriter(percorso));
		}
		else 
			reader = new BufferedReader(new FileReader(percorso));
		
	}
	
	public char getTipo(){
		return tipo;
	}

	public void setTipo(char tipo){
		this.tipo = tipo;
	}
	
	public void scriviFile(String testo) throws IOException, FileException{
		if( getTipo()=='R' || getTipo()=='r' ) throw new FileException("File in lettura");
		
		writer.write(testo);
		writer.newLine();
	}
	
	public String leggiFile() throws IOException, FileException{
		String tmp;
		
		if( getTipo()=='W' || getTipo()=='w') new FileException("File in scrittura!");
		
		tmp = reader.readLine();
		
		if(tmp==null) throw new FileException("Fine del file");
		
		return tmp;
	}
	
	public void chiudiFile() throws IOException {
		if( getTipo()=='R' || getTipo()=='r') reader.close();
		else writer.close();
	}
}
