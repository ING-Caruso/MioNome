package agenda;

import java.time.LocalDate;

public class Appuntamento {
	private LocalDate data;
	private String titolo;
	private String nota;
	
	public Appuntamento(LocalDate data, String titolo, String nota) {
		setData(data);
		setTitolo(titolo);
		setNota(nota);
	}
	public Appuntamento(Appuntamento a1){
		setData(a1.getData());
		setTitolo(a1.getTitolo());
		setNota(a1.getNota());
	}

	public LocalDate getData() {
		return data;
	}

	private void setData(LocalDate data) {
		this.data = data;
	}

	public String getTitolo() {
		return titolo;
	}

	public void setTitolo(String titolo) {
		this.titolo = titolo;
	}

	public String getNota() {
		return nota;
	}

	public void setNota(String nota) {
		this.nota = nota;
	}
}
