package agenda;

import java.io.IOException;
import java.time.LocalDate;


public class Agenda {
	private Appuntamento appuntamenti[];
	private int lunghezza = 15;
	
	public Agenda (){
		appuntamenti = new Appuntamento[lunghezza];
	}
	
	public Agenda(Agenda copia_agenda) {
		appuntamenti = new Appuntamento[lunghezza];
		for(int i = 0; i < lunghezza; i++ ) {
			if(copia_agenda.getAppuntamento(i) != null)
				appuntamenti[i] = copia_agenda.getAppuntamento(i);
		}
	}
	
	public Appuntamento getAppuntamento(int posizione) {
		if((posizione < 0) || (posizione > lunghezza))
			return null;
		if(appuntamenti[posizione] != null)
			return new Appuntamento(appuntamenti[posizione]);
		else
			return null;
	}
	
	public void aggiungiAppuntamento(Appuntamento a1, int posizione) {
		try {	
			if(appuntamenti[posizione] == null) {
				appuntamenti[posizione] = new Appuntamento(a1);
				System.out.println("Appuntamento Aggiunto");
				lunghezza++;
			}
			else
				System.out.println("Giorno Occupato");
				}
		catch(ArrayIndexOutOfBoundsException exception) {
			System.out.println("Posizione non valida");
		}
			
	}
	public void rimuoviAppuntamento(Appuntamento a1) {
		try {
			for(int i = 0; i < lunghezza-1; i++)
				if(appuntamenti[i].getData().equals(a1.getData()) && appuntamenti[i].getTitolo().equals(a1.getTitolo()) && appuntamenti[i].getNota().equals(a1.getNota())) {
					appuntamenti[i] = null;
					System.out.println("Appuntamento Rimosso");
				}
				else
					System.out.println("Appuntamento Non Trovato");
		}
		catch(ArrayIndexOutOfBoundsException exception) {}
		catch(NullPointerException exception) {}
	}
	
	public void stampaInfo() {
		for(int i = 0; i < lunghezza; i++) {
				try {
					System.out.print("Posizione " + i + " : " + getAppuntamento(i).getData() + " ");
					System.out.print(getAppuntamento(i).getTitolo() + " ");
					System.out.println(getAppuntamento(i).getNota() + " ");
				}
							
				catch(NullPointerException exception) {
					System.out.println("Posizione " + i + " : Posizione Vuota");	
				}
				catch(ArrayIndexOutOfBoundsException exception) {}
		}

	}
	public void modificaAppuntamento(Appuntamento a1,Appuntamento a2) {
		try {
			for(int i = 0; i < lunghezza-1; i++)
				if(appuntamenti[i].getData().equals(a1.getData()) && appuntamenti[i].getTitolo().equals(a1.getTitolo()) && appuntamenti[i].getNota().equals(a1.getNota())) {
					appuntamenti[i] = new Appuntamento(a2);
					System.out.println("Appuntamento Modificato");
				}
				else
					System.out.println("Appuntamento Non Trovato");
		}
		catch(ArrayIndexOutOfBoundsException exception) {}
		catch(NullPointerException exception) {}
	}
	public void salvaAgenda() throws IOException {
		
		String percorso = "file.txt";
		File impegni = new File(percorso, 'W');
				try {
			
				for(int i = 0; i < lunghezza-1; i++) {
					try {
						if(getAppuntamento(i).getData() != null) {
							String titolo = getAppuntamento(i).getTitolo();
							String data = getAppuntamento(i).getData().toString();
							String nota = getAppuntamento(i).getNota();
							impegni.scriviFile(data + " " + titolo + " " + nota);
						}
					}
					catch(ArrayIndexOutOfBoundsException exception) {
					}
					catch(NullPointerException exception) {
						
					}
				}
			}
		catch(FileException exception) {
			System.out.println(exception.getMessage());	
		}
		impegni.chiudiFile();
	}
	
	public void caricaAgenda(String percorso) throws IOException {
		int lunghezza_stringa = 0,j = 0;
		String[] array = new String[100];
		String s1data = new String();
		String s2 = new String();
		String s3titolo = new String();
		String s4nota = new String();
		File agenda = new File(percorso, 'R');
		String line;
		Appuntamento app;
		try {
			while(true) {
				line = agenda.leggiFile();
				array[j] = line;
				//System.out.println(line);
				j++;
			}
		}
			catch(FileException exception) {
				System.out.println(exception.getMessage());	
			}
		for(int i = 0; i < lunghezza; i++) {
			try {
				lunghezza_stringa = array[i].length();
				int primo = array[i].indexOf(' ');
				s1data = array[i].substring(0,primo);
				s2 = array[i].substring(0,primo) + 'k' + array[i].substring(primo +1);
				int secondo = s2.indexOf(' ');
				s3titolo = s2.substring(primo+1,secondo);
				s4nota = array[i].substring(secondo+1,lunghezza_stringa);
				app = new Appuntamento(LocalDate.parse(s1data),s3titolo,s4nota);
				aggiungiAppuntamento(app,i);
			}
			catch(NullPointerException exception) {}
			agenda.chiudiFile();
		}
	}
}