package membristatici.figure.geometriche;

public class Rettangolo extends Poligono {
	private final double base;
	private final double altezza;
	private double area;
	
	public Rettangolo(double base, double altezza) {
		this.altezza = altezza;
		this.base = base;
	}
	
	public double getBase() {
		return base;
	}
	
	public double getAltezza() {
		return altezza;
	}
	
	public double calcolaArea() {
		area = base*altezza;
		return area;	
	}
}
