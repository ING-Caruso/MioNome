package membristatici.figure.geometriche;

import java.text.DecimalFormat;

public class Main {
	private static DecimalFormat df = new DecimalFormat("#.##");
	public static void main(String[] args) {
		Cerchio c1 = new Cerchio (10);
		Cerchio c2 = new Cerchio (5);
		Quadrato q1 = new Quadrato (8);
		Quadrato q2 = new Quadrato (12);
		Rettangolo r1 = new Rettangolo (4, 8);
		Rettangolo r2 = new Rettangolo (10, 15);
		
		System.out.println("Area Cerchio 1 = " + df.format(c1.calcolaArea()) + "\n");
		System.out.println("Area Cerchio 2 = " + df.format(c2.calcolaArea()) + "\n");
		
		System.out.println("Area Quadrato 1 = " + q1.calcolaArea() + "\n");
		System.out.println("Area Quadrato 2 = " + q2.calcolaArea() + "\n");
		
		System.out.println("Area Rettangolo 1 = " + r1.calcolaArea() + "\n");
		System.out.println("Area Rettangolo 2 = " + r2.calcolaArea() + "\n");

	}

}