package membristatici.figure.geometriche;

public class Cerchio extends Figura{
	private static final double PI_GRECO = Math.PI;
	private final double raggio;
	private double area;
	
	public Cerchio(double raggio){
		this.raggio = raggio;
	}

	public double getRaggio() {
		return raggio;
	}
	
	public double calcolaArea() {
		area = Math.pow(raggio, 2)*PI_GRECO;
		return area;
	}
}
