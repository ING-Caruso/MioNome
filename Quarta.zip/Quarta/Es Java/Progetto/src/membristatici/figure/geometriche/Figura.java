package membristatici.figure.geometriche;

public class Figura {
	
	public Figura() {
	}
	
	public double calcolaArea() {
		return 0;
	}
}
