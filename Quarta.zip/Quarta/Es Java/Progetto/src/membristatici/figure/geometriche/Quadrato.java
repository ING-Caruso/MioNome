package membristatici.figure.geometriche;

public class Quadrato extends Poligono {
	private final double lato;
	private double area;
	
	public Quadrato(double lato) {
		this.lato = lato;
	}
	
	public double getLato() {
		return lato;
	}
	
	public double calcolaArea() {
		area = Math.pow(lato, 2);
		return area;
		
	}

}
