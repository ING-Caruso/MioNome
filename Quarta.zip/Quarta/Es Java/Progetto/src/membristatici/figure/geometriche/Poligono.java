package membristatici.figure.geometriche;

public class Poligono extends Figura{
	public Poligono(){	
	}
	
	public double calcolaArea() {
		return 0;
	}
}
