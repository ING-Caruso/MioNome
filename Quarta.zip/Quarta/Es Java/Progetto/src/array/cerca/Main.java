package array.cerca;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in); 
		int valore = 5;
		int i;
		boolean trova = false;
		int array[] = {0,1,2,3,4,5,6,7,8,9};
		System.out.println("Immetti Numero ");
		valore = input.nextInt();		
		for(i = 0; i < 10; i++)
			if(valore == array[i])
				trova = true;
			
		if(trova == true)
			System.out.println("Numero Trovato");
		else
			System.out.println("Numero Non Trovato");
		
		i=0;
		while(valore == array[i]) {
			if(valore == array[i])
				trova = true;
			else
				i++;
		}
		if(trova == true)
			System.out.println("Numero Trovato");
		else
			System.out.println("Numero Non Trovato");
	}
}