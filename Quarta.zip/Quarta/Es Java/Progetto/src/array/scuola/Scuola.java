package array.scuola;

public class Scuola {
	private Studente array[];
	private int studenti;
	
	
	public Scuola(int studenti){
		this.studenti = studenti;
		array = new Studente[studenti];
	}
	public Scuola(Scuola scuola, int studenti) {
		this.studenti = studenti;
		array = new Studente[studenti];
		for(int i = 0; i < studenti; i++) 
			if(scuola.getStudente(i) != null) 
				array[i] = scuola.getStudente(i);
	}
	
	public Studente getStudente(int posizione) {
		if((posizione < 0) || (posizione > studenti))
			return null;
		
		return array[posizione];
	}
	
	public void aggiungiStudente(Studente studente,int posizione) {
		try {
			if(array[posizione] == null) {
				array[posizione] = studente;
				System.out.println("Studente Aggiunto");
			}
			else
				System.out.println("Posizione già Occupata");
		}
		catch(ArrayIndexOutOfBoundsException exception) {
			System.out.println("Posizione non valida");
		}
		
	}
	
	public void rimuoviStudente(Studente studente) {
		boolean trova = false;
		for(int i = 0; i < studenti; i++)
			if(studente == array[i])
				trova = true;
		
		if(trova == true)
			System.out.println("Studente Rimosso");
		else
			System.out.println("Studente Non Trovato");
	}
	
	public void stampaInfo(Scuola scuola, int alunni) {
		for(int i = 0; i < alunni; i++) {
			try {
				System.out.print("Posizione " + i + " " + scuola.getStudente(i).getNome() + " ");
				System.out.print(scuola.getStudente(i).getCognome() + " ");
				System.out.print(scuola.getStudente(i).getMatricola() + " ");
				System.out.println(scuola.getStudente(i).getEtà());
			}
			catch(NullPointerException exception) {
				System.out.println("Posizione " + i + " Posizione Vuota");	
			}
		}
	}
}
