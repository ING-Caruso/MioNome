package array.scuola;

public class Main {

	public static void main(String[] args) {
		int min = 1000,alunni = 10;
		Studente s1 =  new Studente("Paolo","Rossi",015454545,17);
		Studente s2 =  new Studente("Giuseppe","Verdi",45522545,14);
		Studente s3 =  new Studente("Pippo","SenzaCognome",1055900,18);
		Studente s4 =  new Studente("Nome","Cognome",42258235,18);

		Scuola scuola = new Scuola(alunni);
		scuola.aggiungiStudente(s1, 31);
		scuola.aggiungiStudente(s1, 1);
		scuola.aggiungiStudente(s2, 1);
		scuola.aggiungiStudente(s3, 2);
		scuola.rimuoviStudente(s3);
		scuola.rimuoviStudente(s4);
		
		scuola.stampaInfo(scuola, alunni);
		
		for(int i = 0; i < alunni; i++)
			if(scuola.getStudente(i) != null) 
				if(min >= scuola.getStudente(i).getEtà())
					min = scuola.getStudente(i).getEtà();
		System.out.println("Età minima studenti: " + min);
	}
}