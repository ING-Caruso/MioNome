package array.scuola;

public class Studente {
	private String nome;
	private String cognome;
	private long matricola;
	private int età;
	
	public Studente(String nome, String cognome, long matricola, int età){
		setNome(nome);
		setCognome(cognome);
		setMatricola(matricola);
		setEtà(età);
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCognome() {
		return cognome;
	}
	
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	public long getMatricola() {
		return matricola;
	}
	
	public void setMatricola(long matricola) {
		this.matricola = matricola;
	}
	
	public int getEtà() {
		return età;
	}
	
	public void setEtà(int età) {
		this.età = età;
	}
}
