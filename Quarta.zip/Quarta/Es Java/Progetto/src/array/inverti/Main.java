package array.inverti;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner input = new Scanner (System.in);  
		int array[] = new int[10];
		int pippo[] = new int[10];
		for(int i = 0; i < 10; i++) {
			System.out.println("Immetti Numero ");
			array[i] = input.nextInt();
		}
		System.out.println("Array:");
		for(int i = 0; i < 10; i++)
			System.out.print(array[i]+ "\t");
		
		System.out.println("\n\nArray Invertito :");
		
		for(int i = 0; i < 10; i++){
			pippo[i] = array[10-i-1];
			System.out.print(pippo[i]+ "\t");
		}	

	}

}
