package stringhe;

import java.util.Scanner;

public class Risposta {
	
	public static void main (String args[]) {
		Scanner leggi = new Scanner(System.in);
		String frase = new String ("");
		
		System.out.println("Immetti frase ");
		frase = leggi.nextLine();
		
		int pippo = frase.length() - 1;
		char x = frase.charAt(pippo);
		
		if(x == 63) 
			System.out.println("Non saprei...");
		
		else if(x == 33)
			System.out.println("Hai proprio ragione!");
		
		else
			System.out.println("Mmmm, non mi convince...");
	}
	
}
