package stringhe;

import java.util.Scanner;

public class Confronto {
	
	public static void main ( String args[] ){
		Scanner leggi = new Scanner(System.in);
		String parola1  = new String("");
		String parola2  = new String("");
		System.out.println("Immetti prima parola ");
		parola1 = leggi.nextLine();	
		System.out.println("Immetti Seconda parola ");
		parola2 = leggi.nextLine();	
		boolean uguale = parola1.equals(parola2);
		boolean circa = parola1.equalsIgnoreCase(parola2);
		if(uguale == true)
			System.out.println("Le parole sono uguali ");
		
		else if(uguale == false && circa == true)
			System.out.println("Le parole differsicono per maiuscole ");
		
		else
			System.out.println("Non sono uguali");
	}

}