package lista;

public class ListaException extends Exception{
    private String errore = "";
    ListaException(String errore){
        this.errore = errore;
    }
    String getErrore(){
        return errore;
    }
}
