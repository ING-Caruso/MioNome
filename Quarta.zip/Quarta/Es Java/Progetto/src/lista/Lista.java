package lista;

public class Lista {

    /**
     * @param args
     */

    /*private int i1 = 1;
    private int i2 = 2;
    private int i3 = 3;
    private  int i4 = 4;*/
    private Nodo head;
    private int elementi;

    public Lista() {
        head = null;
        elementi = 0;
    }

    public void scorriLista() {
        while (head != null) {
            System.out.println(head.visualizza()+"q");
            head = head.getLinkNodo();
        }
    }

    public void aggiungiTesta(int info) {
        Nodo n = creaNodo(info,head);
        head = n;
        elementi++;
        return;
    }

    public void aggiungiCoda(int info) {
        if (head == null)
            aggiungiTesta(info);
        else {
            try {
                Nodo n = getLinkPosizione(elementi);
                n.setLinkNodo(creaNodo(info, null));
                elementi++;
            } catch (ListaException exception) {}
            return;
        }
    }

    private Nodo creaNodo(int info ,Nodo n){
        Nodo n1 = new Nodo(info);
        n1.setLinkNodo(n);
        return n1;
    }
    public void eliminaTesta() throws ListaException{
        if (head == null)
            throw new ListaException("Lista vuota");
        head = head.getLinkNodo();
        elementi--;
        return;
    }

    public void eliminaCoda() throws ListaException{
        if (head == null)
            throw new ListaException("Lista vuota");
        Nodo n = getLinkPosizione(elementi - 1);
        n.setLinkNodo(null);
        elementi--;
    }
    private Nodo getLinkPosizione(int i) throws ListaException{
        Nodo n = head;
        int k = 1;
        if(head == null)
            throw new ListaException("Lista vuota");
        if ((i > elementi) || (i < 1))
            throw new ListaException("Posizione errata");
        while ((n.getLinkNodo() != null) && (k < i)) {
            n = n.getLinkNodo();
            k++;
        }
        return n;
    }
    public String lista(Nodo n) {
            if (n == null)
                return "";
            return n.getInfoNodo() + "\n" + lista(n.getLinkNodo());

    }
    public String stampaLista(){
        return lista(head);
    }
    public void aggiungiPosizione(int info, int i) throws ListaException{
        int k = 1;

        if((i <= 1) || (head == null))
            aggiungiTesta(info);
        else {
            if (elementi < i)
                aggiungiCoda(info);
            else {
                Nodo n = getLinkPosizione(i - 1);
                n.setLinkNodo(creaNodo(info, n.getLinkNodo()));
                elementi++;
            }
        }
        return;
    }
    public void eliminaPosizione(int i) throws ListaException{
        if (i <= 1)
            eliminaTesta();
        else
            if(i == elementi)
                eliminaCoda();
            else{
                Nodo n = getLinkPosizione(i);
                Nodo n1 = getLinkPosizione(i - 1);
                n1.setLinkNodo(n.getLinkNodo());
                elementi--;
            }
    }

}
