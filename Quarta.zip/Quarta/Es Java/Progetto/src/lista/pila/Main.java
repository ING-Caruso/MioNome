package lista.pila;

public class Main {
    public static void main(String args[]) {
        int info = 10;
        int info1 = 11;
        int info2 = 12;
        Pila pila = new Pila();
        pila.inserisciInPila(info);
        pila.inserisciInPila(info1);
        pila.inserisciInPila(info2);
        System.out.println(pila.stampaPila());
        pila.estraiPila();
        System.out.println(pila.stampaPila());
    }



}
