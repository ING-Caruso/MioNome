package lista.pila;

public class Pila {
    private Nodo head;

    public Pila(){
        head = null;
    }
    public Nodo creaNodo(int info, Nodo nodo){
        Nodo nodo1 = new Nodo(info);
        nodo1.setLinkNodo(nodo);
        return nodo1;
    }
    public void inserisciInPila(int info){
        Nodo nodo;
        nodo = creaNodo(info,head);
        head = nodo;
    }
    public int estraiPila(){
        Nodo nodo;
        if(head == null)
            return 0;
        nodo = head;
        head = head.getLinkNodo();
        return nodo.getInfoNodo();
    }
    public String pila(Nodo n) {
        if (n == null)
            return "";
        return n.getInfoNodo() + "\n" + pila(n.getLinkNodo());

    }
    public String stampaPila(){
        return pila(head);
    }


}
