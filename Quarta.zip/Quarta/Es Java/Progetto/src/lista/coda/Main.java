package lista.coda;

public class Main {
    public static void main(String[] args){
        int info = 10;
        int info1 = 11;
        int info2 = 12;
        Coda coda = new Coda();
        coda.inserisciInCoda(info);
        coda.inserisciInCoda(info1);
        coda.inserisciInCoda(info2);
        System.out.println(coda.stampaCoda());
        coda.estraiCoda();
        System.out.println(coda.stampaCoda());
    }
}
