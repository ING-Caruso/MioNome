package lista.coda;

public class Coda {
    private Nodo head;
    private Nodo coda;
    public Coda(){
        head = null;
        coda = null;
    }
    private Nodo creaNodo(int info, Nodo nodo){
        Nodo n1 = new Nodo(info);
        n1.setLinkNodo(nodo);
        return n1;
    }
    public void inserisciInCoda(int info) {
        Nodo nodo = creaNodo(info, null);
        if (head == null){
            coda = nodo;
            head = coda;
        }
        else {
            coda.setLinkNodo(nodo);
            coda = nodo;
         }
    }
    public int estraiCoda(){
        Nodo nodo;
        if (head == null)
            return 0;
        nodo = head;
        head = head.getLinkNodo();
        if (head == null)
            coda = null;
        return nodo.getInfoNodo();
    }
    public String coda(Nodo n) {
        if (n == null)
            return "";
        return n.getInfoNodo() + "\n" + coda(n.getLinkNodo());

    }
    public String stampaCoda(){
        return coda(head);
    }
}
