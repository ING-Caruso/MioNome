package lista;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws ListaException {

        int info, pos = 0;

        Lista lista = new Lista();
        Scanner input = new Scanner(System.in);
        //scelta = input.nextInt();
        boolean quit = false;

        do {
            System.out.println("\n");
            System.out.println("#1 aggiungi in testa");
            System.out.println("#2 aggiungi in coda");
            System.out.println("#3 aggiungi in posizone");
            System.out.println("#4 elimina in testa");
            System.out.println("#5 elimina in coda");
            System.out.println("#6 elimina in poszione");
            System.out.println("#7 stampa lista");
            System.out.println("#0 esci");

            System.out.println("Scegli un opzione: ");
            String scelta = input.nextLine();

            switch (scelta) {
                case "1":
                    System.out.println("Immetti un numero");
                    info = input.nextInt();
                    lista.aggiungiTesta(info);
                    break;
                case "2":
                    System.out.println("Immetti un numero");
                    info = input.nextInt();
                    lista.aggiungiCoda(info);
                    break;
                case "3":
                    System.out.println("Immetti un numero");
                    info = input.nextInt();
                    System.out.println("Immetti posizione");
                    pos = input.nextInt();
                    lista.aggiungiPosizione(info, pos);
                    break;
                case "4":
                    System.out.println("Hai eliminato il nodo in testa");
                    lista.eliminaTesta();
                    break;
                case "5":
                    System.out.println("Hai eliminato il nodo in coda");
                    lista.eliminaCoda();
                    break;
                case "6":
                    System.out.println("Immetti posizione");
                    pos = input.nextInt();
                    lista.eliminaPosizione(pos);
                    System.out.println("Hai eliminato il nodo nella poszione numero " + pos);
                    break;
                case "7":
                    System.out.println(lista.stampaLista());
                    break;

            default:
                System.out.println("scegli un' opzione valida");
        }

    } while (!quit);

        System.out.println("Fine del programma");
}
}