package lista.misuracoda;

import lista.coda.Coda;

import java.time.Instant;
import java.util.Random;

public class Main {
    public static void main(String[] args) throws InterruptedException {

        Coda coda = new Coda();
        Random rand = new Random();
        Instant inizio = Instant.now();
            for (int i = 0; i < 8000; i++)
                coda.inserisciInCoda(rand.nextInt(500));
        Instant fine = Instant.now();
        long tempo = fine.getNano() - inizio.getNano();
        System.out.println(coda.stampaCoda());
        System.out.println("Tempo impiegato " + tempo + " nanosecondi");
        System.out.println("Tempo impiegato " + tempo/1000 + " millisecondi");

    }
}
