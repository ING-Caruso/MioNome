package Progetto;

public class Studente extends Persona{
    private String classe_frequentata;
    
    public Studente(String cognome, String nome, String codice_fiscale,String classe_frequentata){
        super(cognome,nome,codice_fiscale);
        this.classe_frequentata=classe_frequentata;
    }

    public void setClasse_frequentata(String classe_frequentata){
        this.classe_frequentata=classe_frequentata;
    }
    
    public String getClasse_frequentata(){
        return classe_frequentata;
    }
    public void stampaInfo() {
    	super.stampaInfo();
    	System.out.println("Classe Frequentata = " + classe_frequentata);
    	System.out.println("");
    }
}
