package Progetto;

public class Docente extends Persona{
    private String materia_insegnata;
    
    public Docente(String cognome, String nome, String codice_fiscale,String materia_insegnata){
        super(cognome,nome,codice_fiscale);
        this.materia_insegnata=materia_insegnata;
    }

    public void setMateria_insegnata(String materia_insegnata){
        this.materia_insegnata=materia_insegnata;
    }
    
    public String getMateria_insegnata(){
        return materia_insegnata;
    }
    public void stampaInfo() {
    	super.stampaInfo();
    	System.out.println("Materia Insegnata = "+ materia_insegnata);
    	System.out.println("");
    }
}
