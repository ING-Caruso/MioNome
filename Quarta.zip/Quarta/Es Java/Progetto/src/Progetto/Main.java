package Progetto;

public class Main {

	public static void main(String[] args) {
		Docente d1 = new Docente("Daniele","Lombardo","LM1DN100Z00Z123W","Informatica");
		Docente d2 = new Docente("Luciano","Carlotti","CR1LN200Z00Z456W","Informatica");
		Studente s1 = new Studente ("Enrico","Fermi","FR9EN900Q00S654P","4BIF" );
		Studente s2 = new Studente ("Giovanni","Giorgi","GR5GV501R00F321J","4BIF");
		Studente s3 = new Studente ("Sandro","Pertini","PT3SD201C00G963H","4BIF");
		System.out.println("Docente 1 :");
		d1.stampaInfo();
		System.out.println("Docente 2 :");
		d2.stampaInfo();
		System.out.println("Studente 1 :");
		s1.stampaInfo();
		System.out.println("Studente 2 :");
		s2.stampaInfo();
		System.out.println("Studente 3 :");
		s3.stampaInfo();
	}

}
