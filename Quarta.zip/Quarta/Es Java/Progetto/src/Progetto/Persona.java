package Progetto;
public class Persona{
	private String cognome;
	private String nome;
	private String codice_fiscale;

    public Persona(String nome, String cognome, String codice_fiscale){
    	this.nome=nome;
    	this.cognome=cognome;
        this.codice_fiscale=codice_fiscale;
     }

    public String getNome(){
        return nome;
    }
    
    public String getCognome(){
        return cognome;
    }
    
    public String getCodice_fiscale(){
        return codice_fiscale;
    }
    
    public void setNome(String nome){
        this.nome=nome;
    }
    
    public void setCognome(String cognome){
        this.cognome=cognome;
    }
    
    public void setCodice_fiscale(String codice_fiscale){
        this.codice_fiscale=codice_fiscale;   
    }
    
    public void stampaInfo() {
    	System.out.println("Nome = "+ nome);
    	System.out.println("Cognome = "+ cognome);
    	System.out.println("Codice Fiscale = "+ codice_fiscale);
    }
}