fun main(args: Array<String>) {
    val voto : Int = readln().toInt()
    val risultato=when(voto)
    {
        in 0..4 -> "Gravemente insufficiente"
        5 -> "Insufficiente"
        in 6..8 -> "Buono"
        9, 10 -> "Ottimo"
        else -> "Valore non valido"
    }
    println(risultato)
}