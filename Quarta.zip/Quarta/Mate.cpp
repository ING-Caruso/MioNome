#include <iostream>
#define _USE_MATH_DEFINES
#include <math.h>
using namespace std;
double segno(double,double);
void stampa(string);
	int main(){
		int scelta;
		double x,rad,deg,A2,S1,S2;
		char ma = 62;
		char min = 60;
		char s;
		while(true){
			system("pause");
			system("cls");
			cout<<"Comando 1 Seno "<<endl;
			cout<<"Comando 2 Coseno "<<endl;
			cout<<"Comando 3 Tangente "<<endl;
			cout<<"Comando 4 Esci \n"<<endl;
			cout<<"Immetti Scelta ";
			cin>>scelta;
			switch(scelta){
				case 1:
					cout<<"Immetti Seno ";
					cin>>x;
					cout<<"Immetti Segno ";
					cin>>s;
					rad=asin(x);
					deg = rad*180/M_PI;
					if(s == min && x==1)
						cout<<"Verificato per tutti i valori \n";
					else if (s == ma && x>1)
						cout<<"Impossibile \n";
					else {
						if(deg < 0){
							deg = rad*180/M_PI*(-1)+180;
							A2 = 180-deg+360 ;
						}
						else {
							deg = rad*180/M_PI;	
							A2 = 180 - deg;
						}
							S1 = round (deg);
							S2 = round (A2);
							if(s==min)
								cout<<S1<<" +2k Pi < x < "<<S2<<" +2k Pi \n";
							else if(s==ma)
								cout<<S1<<" +2k Pi > x > "<<S2<<" +2k Pi \n";
							else 
								cout<<"Errore \n";
					}
					break;
					
				case 2:
					cout<<"Immetti Coseno ";
					cin>>x;
					cout<<"Immetti Segno ";
					cin>>s;
					rad=acos(x);
					deg = rad*180/M_PI;
					if(s == min && x==1)
						cout<<"Verificato per tutti i valori \n";
					else if(s == ma && x>1)
						cout<<"Impossibile \n";
					else{
					if(deg < 0){
						deg = rad*180/M_PI*(-1)+90;
						A2 = deg ;
					}
					else {
						deg = rad*180/M_PI;	
						A2 = 360 - deg;
					}
						S1 = round (deg);
						S2 = round (A2);
						
						if(s==min)
							cout<<S1<<" +2k Pi < x < "<<S2<<" +2k Pi \n";
						else if(s==ma)
							cout<<S1<<" +2k Pi > x > "<<S2<<" +2k Pi \n";
						else 
							cout<<"Errore \n";
					}
					break;
					
				case 3:
					cout<<"Immetti Tangente ";
					cin>>x;
					cout<<"Immetti Segno ";
					cin>>s;
					rad=atan(x);
					deg = rad*180/M_PI;
					if(s == min && x==1)
						cout<<"Verificato per tutti i valori \n";
					else if(s == ma && x>1)
						cout<<"Impossibile \n";
					else{
						if(deg < 0){
							deg = rad*180/M_PI+180;
							A2 = deg ;
						}
						else 
							deg = rad*180/M_PI;	
						A2 = 180 + deg;
						S1 = round (deg);
						S2 = round (A2);
						if(s==min)
							cout<<S1<<" +2k Pi < x < "<<S2<<" +2k Pi \n";
						else if(s==ma)
							cout<<S1<<" +2k Pi > x > "<<S2<<" +2k Pi \n";
						else
						cout<<"Errore \n";
					}
					break;
					
				case 4:
					return 0; 
					break;
			}
		}
	}
