
/**
 * Aggiungi qui una descrizione della classe Studente
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class Studente extends Persona{
    // variabili d'istanza - sostituisci l'esempio che segue con il tuo
    private String classe_frequentata;
    

    /**
     * Costruttore degli oggetti di classe  Studente
     */
    public Studente(String cognome, String nome, String codice_fiscale,String classe_frequentata){
        // inizializza le variabili d'istanza
        super(cognome,nome,codice_fiscale);
        this.classe_frequentata=classe_frequentata;
    }

    public void setClasse_frequentata(String classe_frequentata){
        // metti qui il tuo codice
        this.classe_frequentata=classe_frequentata;
    }
    public String getClasse_frequentata(){
        // metti qui il tuo codice
        return classe_frequentata;
    }
}
