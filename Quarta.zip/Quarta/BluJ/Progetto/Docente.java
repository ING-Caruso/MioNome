
/**
 * Aggiungi qui una descrizione della classe Docente
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class Docente extends Persona{
    // variabili d'istanza - sostituisci l'esempio che segue con il tuo
   private String materia_insegnata;

    /**
     * Costruttore degli oggetti di classe  Docente
     */
    public Docente(String cognome, String nome, String codice_fiscale, String materia_insegnata){
        super(cognome,nome,codice_fiscale);
        this.materia_insegnata=materia_insegnata; 
    }

    public void setMateria_insegnata(String materia_insegnata){
        // metti qui il tuo codice
       this.materia_insegnata=materia_insegnata;
    }
    
    public String getMateria_frequentata(){
        // metti qui il tuo codice
        return this.materia_insegnata;
    }
}
