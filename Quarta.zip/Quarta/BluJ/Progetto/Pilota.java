
/**
 * Aggiungi qui una descrizione della classe Pilota
 * 
 * @author (il tuo nome) 
 * @version (un numero di versione o una data)
 */
public class Pilota{
    // variabili d'istanza - sostituisci l'esempio che segue con il tuo
    private String cognome;
    private String nome;
    private int anno;
    private int punti;

    /**
     * Costruttore degli oggetti di classe  Pilota
     */
    public Pilota(String c, String n, int a){
        // inizializza le variabili d'istanza
        cognome=c;
        nome=n;
        anno=a;
        punti=30;
    }

    /**
     * Un esempio di metodo - aggiungi i tuoi commenti
     * 
     * @param  y   un parametro d'esempio per un metodo
     * @return     la somma di x e y
     */
    public String getNome(){
        // metti qui il tuo codice
        return nome;
    }
    public String getCogome(){
        // metti qui il tuo codice
        return cognome;
    }
    public int getAnno(){
        // metti qui il tuo codice
        return anno;
    }
    public int getPunti(){
        // metti qui il tuo codice
        return punti;
    }
    public void setNome(String c){
        // metti qui il tuo codice
        cognome=c;
    }
    public void setCogome(String n){
        // metti qui il tuo codice
        nome=n;
    }
    public void setAnno(int a){
        // metti qui il tuo codice
        anno=a;
    }
    public void setPunti(int p){
        // metti qui il tuo codice
        punti=p;
    }
}
