
/**
 * Aggiungi qui una descrizione della classe Persona
 * 
 * @author ING.Caruso 
 * @version (un numero di versione o una data)
 */
public class Persona
{
    private String cognome;
    private String nome;
    private String codice_fiscale;

    /**
     * Costruttore degli oggetti di classe  Persona
     */
    public Persona(String cognome, String nome, String codice_fiscale){
        this.cognome=cognome;
        this.nome=nome;
        this.codice_fiscale=codice_fiscale;
    }

   
    public String getNome(){
        return nome;
    
    }
    public String getCognome(){
        return cognome;
    
    }
    public String getCodice_fiscale(){
        return codice_fiscale;
        
    }
    public void setNome(String nome){
        this.nome=nome;
    
    }
    public void setCognome(String cognome){
        this.cognome=cognome;
    
    }
    public void setCodice_fiscale(String codice_fiscale){
        this.codice_fiscale=codice_fiscale;
        
    }
}
