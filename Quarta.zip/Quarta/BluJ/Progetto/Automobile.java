
/**
 * Aggiungi qui una descrizione della classe Automobile
 * 
 * @author ING.Caruso 
 * @version (un numero di versione o una data)
 */
public class Automobile{
    // variabili d'istanza - sostituisci l'esempio che segue con il tuo
    private String marca;
    private String modello;
    private String colore;
    private int cilindrata;
    private int anno;

    /**
     * Costruttore degli oggetti di classe  Automobile
     */
    public Automobile(String ma, String mo, String c, int cil, int a){
        // inizializza le variabili d'istanza
        marca=ma;
        modello=mo;
        colore=c;
        cilindrata=cil;
        anno=a;
    }

    /**
     * Un esempio di metodo - aggiungi i tuoi commenti
     * 
     * @param  y   un parametro d'esempio per un metodo
     * @return     la somma di x e y
     */
    public String getMarca(){
        // metti qui il tuo codice
        return marca;
    
    }
    public String getModello(){
        // metti qui il tuo codice
        return modello;
    
    }
    public String getColore(){
        // metti qui il tuo codice
        return colore;
    
    }
    public int getCilindrata(){
        // metti qui il tuo codice
        return cilindrata;
    
    }
    public int getAnno(){
        // metti qui il tuo codice
        return anno;
    
    }
    public void setMarca(String ma){
        // metti qui il tuo codice
        marca=ma;
    
    }
       public void setModello(String mo){
        // metti qui il tuo codice
        modello=mo;
    
    }
       public void setColore(String c){
        // metti qui il tuo codice
        colore=c;
    
    }
       public void setCilindrata(int cil){
        // metti qui il tuo codice
        cilindrata=cil;
    
    }
       public void setAnno(int a){
        // metti qui il tuo codice
        anno=a;
    
    }
    
}
